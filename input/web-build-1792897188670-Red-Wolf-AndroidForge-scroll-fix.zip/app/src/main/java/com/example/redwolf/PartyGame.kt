package com.example.redwolf

import org.json.JSONArray
import org.json.JSONObject

/**
 * Host-authoritative Werewolves game state. Only stateFor() values are sent to
 * devices; each snapshot contains that device's own role and permitted clues.
 */
internal class PartyGame {
    private data class Player(val id: String, val name: String, var role: String, var alive: Boolean = true)

    private val players = LinkedHashMap<String, Player>()
    private var phase = "LOBBY"
    private var day = 0
    private val ready = linkedSetOf<String>()
    private val chiefCandidates = mutableListOf<String>()
    private val chiefVotes = LinkedHashMap<String, String>()
    private var chiefId: String? = null
    private var pendingChiefSuccessorId: String? = null
    private var chiefSuccessionReturnPhase = "MORNING"
    private val wolfProposals = LinkedHashMap<String, String>()
    private val wolfConfirmations = LinkedHashMap<String, String>()
    private val trustVotes = LinkedHashMap<String, String>()
    private val seerTargets = LinkedHashMap<String, String>()
    private val seerReports = LinkedHashMap<String, String>()
    private var publicSeerReport = ""
    private var wolfTargetId: String? = null
    private var wolvesLocked = false
    private var wolfDeadlineAtMs = 0L
    private var nightDeadlineAtMs = 0L
    private var witchHealed = false
    private var witchPoisonTargetId: String? = null
    private var witchHealCharges = 0
    private var witchKillCharges = 0
    private var witchTurnSubmitted = false
    private var protectorTargetId: String? = null
    private var protectorSelfUsed = false
    private var protectorOtherUsed = false
    private var protectorTurnSubmitted = false
    private var pendingHunterId: String? = null
    private var hunterReturnPhase = "MORNING"
    private val nightDeaths = linkedSetOf<String>()
    private val nightDeathAnnouncements = LinkedHashMap<String, String>()
    private val nightProtectionAnnouncements = LinkedHashMap<String, String>()
    private var morningSummary = ""
    private val events = mutableListOf<String>()
    private val voterOrder = mutableListOf<String>()
    private val villageVotes = LinkedHashMap<String, String>()
    private var voteIndex = 0
    private var lastVoteResult = ""
    private var voteAnnouncementSequence = 0
    private var latestVoteAnnouncement = JSONObject()

    val isStarted: Boolean
        @Synchronized get() = phase != "LOBBY"

    val currentPhase: String
        @Synchronized get() = phase

    @Synchronized
    fun wolfAgreementDeadline(): Long = wolfDeadlineAtMs

    @Synchronized
    fun nightDeadline(): Long = nightDeadlineAtMs

    /**
     * Returns an explanation if the selected setup cannot be dealt, otherwise
     * initializes a fresh game with a newly shuffled role deck.
     */
    @Synchronized
    fun start(
        playerNames: Map<String, String>,
        wolfCount: Int,
        enabledRoles: Set<String>,
        witchKills: Int,
        witchHeals: Int,
    ): String? {
        val specialCount = wolfCount + enabledRoles.size
        val townCount = playerNames.size - wolfCount
        if (playerNames.size <= specialCount) {
            return "Add at least one more player so the game includes a Villager."
        }
        if (wolfCount >= townCount) {
            return "Add players or reduce the Wolf count so the Villagers outnumber the Wolves."
        }
        if (playerNames.size < 3) {
            return "At least three players are needed."
        }

        players.clear()
        val deck = mutableListOf<String>()
        repeat(wolfCount) { deck.add("WOLF") }
        enabledRoles.forEach { deck.add(it) }
        while (deck.size < playerNames.size) deck.add("VILLAGER")
        deck.shuffle()
        playerNames.entries.forEachIndexed { index, entry ->
            players[entry.key] = Player(entry.key, entry.value, deck[index])
        }

        phase = "ROLE_REVEAL"
        day = 0
        ready.clear()
        chiefCandidates.clear()
        chiefVotes.clear()
        chiefId = null
        pendingChiefSuccessorId = null
        chiefSuccessionReturnPhase = "MORNING"
        wolfProposals.clear()
        wolfConfirmations.clear()
        trustVotes.clear()
        seerTargets.clear()
        seerReports.clear()
        publicSeerReport = ""
        wolfTargetId = null
        wolvesLocked = false
        wolfDeadlineAtMs = 0L
        nightDeadlineAtMs = 0L
        witchHealed = false
        witchPoisonTargetId = null
        witchHealCharges = if ("WITCH" in enabledRoles) witchHeals.coerceIn(1, 2) else 0
        witchKillCharges = if ("WITCH" in enabledRoles) witchKills.coerceIn(1, 2) else 0
        witchTurnSubmitted = false
        protectorTargetId = null
        protectorSelfUsed = false
        protectorOtherUsed = false
        protectorTurnSubmitted = false
        pendingHunterId = null
        hunterReturnPhase = "MORNING"
        nightDeaths.clear()
        nightDeathAnnouncements.clear()
        nightProtectionAnnouncements.clear()
        morningSummary = ""
        events.clear()
        voterOrder.clear()
        villageVotes.clear()
        voteIndex = 0
        lastVoteResult = ""
        voteAnnouncementSequence = 0
        latestVoteAnnouncement = JSONObject()
        addEvent("Roles were dealt privately. Each player can see only their own role.")
        return null
    }

    @Synchronized
    fun handle(playerId: String, hostId: String, message: JSONObject): Boolean {
        if (phase == "LOBBY") return false
        val action = message.optString("action")
        val player = players[playerId] ?: return false
        return when (action) {
            "ready" -> {
                if (phase != "ROLE_REVEAL" || !player.alive || !ready.add(playerId)) return false
                if (aliveIds().all { ready.contains(it) }) beginChiefElection()
                true
            }

            "chiefVote" -> {
                val candidateId = message.optString("targetId")
                if (phase != "CHIEF_ELECTION" || !player.alive || chiefVotes.containsKey(playerId) ||
                    candidateId !in chiefCandidates || candidateId == playerId
                ) return false
                chiefVotes[playerId] = candidateId
                recordVoteAnnouncement(playerId, candidateId, "CHIEF")
                if (aliveIds().all { chiefVotes.containsKey(it) }) finishChiefElection()
                true
            }

            "beginNight" -> {
                if (playerId != hostId || phase != "CHIEF_RESULT") return false
                beginNight()
                true
            }

            "chooseChiefSuccessor" -> {
                val targetId = message.optString("targetId")
                if (phase != "CHIEF_SUCCESSION" || playerId != pendingChiefSuccessorId ||
                    players[targetId]?.alive != true || targetId == playerId
                ) return false
                chiefId = targetId
                addEvent("${nameOf(playerId)} chose ${nameOf(targetId)} as the new Village Chief.")
                pendingChiefSuccessorId = null
                phase = chiefSuccessionReturnPhase
                true
            }

            "wolfPropose" -> {
                val targetId = message.optString("targetId")
                if (!wolfActionsOpen() || !player.alive ||
                    player.role != "WOLF" || !isAliveNonWolf(targetId)
                ) return false
                if (wolfProposals[playerId] != targetId) {
                    wolfProposals[playerId] = targetId
                    wolfConfirmations.remove(playerId)
                }
                true
            }

            "wolfConfirm" -> {
                val proposal = wolfProposals[playerId] ?: return false
                if (!wolfActionsOpen() || !player.alive ||
                    player.role != "WOLF" || wolfConfirmations[playerId] == proposal ||
                    !isAliveNonWolf(proposal)
                ) return false
                wolfConfirmations[playerId] = proposal
                val livingWolves = aliveWolfIds()
                if (livingWolves.isNotEmpty() && livingWolves.all { wolfId ->
                        wolfProposals[wolfId] == proposal && wolfConfirmations[wolfId] == proposal
                    }
                ) {
                    wolfTargetId = proposal
                    wolvesLocked = true
                    finishNightEarlyIfReady()
                }
                true
            }

            "trustVote" -> {
                val targetId = message.optString("targetId")
                if (!nightActionsOpen() || !player.alive || player.role == "WOLF" ||
                    trustVotes.containsKey(playerId) || !isAliveOther(playerId, targetId)
                ) return false
                trustVotes[playerId] = targetId
                true
            }

            "lockWolfAgreement" -> {
                if (playerId != hostId || phase != "NIGHT_ACTIVITY" ||
                    System.currentTimeMillis() < wolfDeadlineAtMs
                ) return false
                lockWolfAgreement()
                finishNightEarlyIfReady()
                true
            }

            "endNight" -> {
                if (playerId != hostId || phase != "NIGHT_ACTIVITY" ||
                    System.currentTimeMillis() < nightDeadlineAtMs
                ) return false
                if (!wolvesLocked) lockWolfAgreement()
                if (wolfTargetId == null) {
                    if (witchHealed) witchHealCharges++
                    if (witchPoisonTargetId != null) witchKillCharges++
                    witchHealed = false
                    witchPoisonTargetId = null
                }
                resolveNight()
                true
            }

            "seer" -> {
                val targetId = message.optString("targetId")
                if (!nightActionsOpen() || !player.alive || player.role != "SEER" ||
                    seerTargets.containsKey(playerId) || !isAliveOther(playerId, targetId)
                ) return false
                seerTargets[playerId] = targetId
                seerReports[playerId] = "${nameOf(targetId)} is a ${roleTitle(players[targetId]?.role ?: "VILLAGER")}."
                publicSeerReport = if (players[targetId]?.role == "WOLF") {
                    "The Seer saw a Wolf."
                } else {
                    "The Seer saw a Villager."
                }
                finishNightEarlyIfReady()
                true
            }

            "witch" -> {
                val poisonId = message.optString("poisonTargetId").takeIf { it.isNotBlank() }
                val useHeal = message.optBoolean("heal", false)
                if (!nightActionsOpen() || !wolvesLocked || !player.alive ||
                    player.role != "WITCH" || witchTurnSubmitted
                ) return false
                if (useHeal && (witchHealCharges <= 0 || wolfTargetId == null)) return false
                if (poisonId != null &&
                    (witchKillCharges <= 0 || players[poisonId]?.alive != true || poisonId == playerId)
                ) return false
                witchHealed = useHeal
                if (useHeal) witchHealCharges--
                witchPoisonTargetId = poisonId
                if (poisonId != null) witchKillCharges--
                witchTurnSubmitted = true
                finishNightEarlyIfReady()
                true
            }

            "protect", "skipProtect" -> {
                if (!nightActionsOpen() || !player.alive || player.role != "SALVATEUR" ||
                    protectorTurnSubmitted
                ) return false
                if (action == "protect") {
                    val targetId = message.optString("targetId")
                    if (players[targetId]?.alive != true) return false
                    if (targetId == playerId) {
                        if (protectorSelfUsed) return false
                        protectorSelfUsed = true
                    } else {
                        if (protectorOtherUsed) return false
                        protectorOtherUsed = true
                    }
                    protectorTargetId = targetId
                }
                protectorTurnSubmitted = true
                finishNightEarlyIfReady()
                true
            }

            "hunterShot", "skipHunter" -> {
                if (phase != "HUNTER_ACTION" || pendingHunterId == null) return false
                if (action == "skipHunter") {
                    if (playerId != hostId) return false
                } else {
                    if (playerId != pendingHunterId) return false
                    val targetId = message.optString("targetId")
                    if (players[targetId]?.alive != true || targetId == pendingHunterId) return false
                    eliminate(targetId)
                    addEvent("A final shot killed ${nameOf(targetId)}.")
                    lastVoteResult = "${nameOf(targetId)} was killed by a final shot."
                }
                pendingHunterId = null
                continueAfterHunter()
                true
            }

            "startDiscussion" -> {
                if (playerId != hostId || phase != "MORNING") return false
                phase = "DISCUSSION"
                addEvent("The village is awake. Discuss before setting the ballot order.")
                true
            }

            "beginOrder" -> {
                if (phase != "DISCUSSION" || !maySetOrder(playerId, hostId)) return false
                voterOrder.clear()
                villageVotes.clear()
                voteIndex = 0
                phase = "ORDER_SETUP"
                true
            }

            "setOrder" -> {
                if (phase != "ORDER_SETUP" || !maySetOrder(playerId, hostId)) return false
                val ids = message.optJSONArray("ids") ?: return false
                val chosen = (0 until ids.length()).map { ids.optString(it) }
                val living = aliveIds()
                if (chosen.size != living.size || chosen.toSet() != living.toSet()) return false
                voterOrder.clear()
                voterOrder.addAll(chosen)
                villageVotes.clear()
                voteIndex = 0
                phase = "VILLAGE_VOTE"
                addEvent("${nameOf(playerId)} set the public voting order.")
                true
            }

            "villageVote" -> {
                if (phase != "VILLAGE_VOTE" || voteIndex !in voterOrder.indices ||
                    voterOrder[voteIndex] != playerId || !player.alive
                ) return false
                val targetId = message.optString("targetId")
                if (!isAliveOther(playerId, targetId) || villageVotes.containsKey(playerId)) return false
                villageVotes[playerId] = targetId
                recordVoteAnnouncement(playerId, targetId, "VILLAGE")
                voteIndex++
                if (voteIndex >= voterOrder.size) finishVillageVote()
                true
            }

            "startNextNight" -> {
                if (playerId != hostId || phase != "DAY_RESULT") return false
                beginNight()
                true
            }

            else -> false
        }
    }

    @Synchronized
    fun stateFor(playerId: String, hostId: String): JSONObject {
        val me = players[playerId]
        val state = JSONObject()
            .put("type", "gameState")
            .put("phase", phase)
            .put("day", day)
            .put("isHost", playerId == hostId)
            .put("players", JSONArray().apply {
                players.values.forEach { put(playerJson(it)) }
            })
            .put("events", JSONArray().apply { events.takeLast(80).forEach { put(it) } })
            .put("chiefCandidates", JSONArray().apply {
                chiefCandidates.forEach { id -> put(JSONObject().put("id", id).put("name", nameOf(id))) }
            })
            .put("chiefId", chiefId ?: "")
            .put("chiefName", chiefId?.let { nameOf(it) } ?: "")
            .put("chiefAlive", chiefId?.let { players[it]?.alive == true } ?: false)
            .put("readyCount", ready.size)
            .put("readyTotal", aliveIds().size)
            .put("voterOrder", JSONArray().apply {
                voterOrder.forEach { id -> put(JSONObject().put("id", id).put("name", nameOf(id))) }
            })
            .put("currentVoterId", voterOrder.getOrNull(voteIndex) ?: "")
            .put("voteCounts", voteCountsJson())
            .put("ballotsCast", when (phase) {
                "CHIEF_ELECTION", "CHIEF_RESULT" -> chiefVotes.size
                "VILLAGE_VOTE", "DAY_RESULT" -> villageVotes.size
                else -> 0
            })
            .put("ballotsTotal", when (phase) {
                "CHIEF_ELECTION", "CHIEF_RESULT" -> aliveIds().size
                "VILLAGE_VOTE", "DAY_RESULT" -> voterOrder.size
                else -> 0
            })
            .put("lastVoteResult", lastVoteResult)
            .put("morningSummary", morningSummary)
            .put("publicSeerReport", publicSeerReport)
            .put("voteAnnouncementSequence", voteAnnouncementSequence)
            .put("latestVoteAnnouncement", JSONObject(latestVoteAnnouncement.toString()))
            .put("nightPuzzleOpen", phase in setOf(
                "NIGHT_ACTIVITY",
                "NIGHT_WOLF",
                "NIGHT_SEER",
                "NIGHT_WITCH",
                "NIGHT_PROTECTOR",
            ) &&
                System.currentTimeMillis() < nightDeadlineAtMs)
            .put("nightDeathAnnouncements", JSONArray().apply {
                nightDeathAnnouncements.forEach { (id, cause) ->
                    put(JSONObject().put("playerName", nameOf(id)).put("cause", cause))
                }
            })
            .put("nightProtectionAnnouncements", JSONArray().apply {
                nightProtectionAnnouncements.forEach { (id, cause) ->
                    put(JSONObject().put("playerName", nameOf(id)).put("cause", cause))
                }
            })
            .put("winner", winnerText())
            .put("myRole", me?.role ?: "")
            .put("myAlive", me?.alive == true)
            .put("myActionDone", actionDone(playerId))
            .put("canStartNight", playerId == hostId && phase == "CHIEF_RESULT")
            .put("nightRemainingMs", if (phase == "NIGHT_ACTIVITY") {
                (nightDeadlineAtMs - System.currentTimeMillis()).coerceAtLeast(0L)
            } else 0L)
            .put("canEndNight", playerId == hostId && phase == "NIGHT_ACTIVITY" &&
                System.currentTimeMillis() >= nightDeadlineAtMs)
            .put("canStartDiscussion", playerId == hostId && phase == "MORNING")
            .put("canSkipHunter", playerId == hostId && phase == "HUNTER_ACTION")
            .put("canSetOrder", (phase == "DISCUSSION" || phase == "ORDER_SETUP") && maySetOrder(playerId, hostId))
            .put("canStartNextNight", playerId == hostId && phase == "DAY_RESULT")
            .put("canChooseChiefSuccessor", phase == "CHIEF_SUCCESSION" && playerId == pendingChiefSuccessorId)

        if (phase == "CHIEF_SUCCESSION" && playerId == pendingChiefSuccessorId) {
            state.put("chiefSuccessorCandidates", JSONArray().apply {
                aliveIds().filter { it != playerId }.forEach { id ->
                    put(JSONObject().put("id", id).put("name", nameOf(id)))
                }
            })
        }
        if (me?.role == "WOLF") {
            state.put("wolfFriends", JSONArray().apply {
                aliveWolfIds().filter { it != playerId }.forEach { put(nameOf(it)) }
            })
            state.put("wolfTargets", JSONArray().apply {
                aliveNonWolfIds().forEach { id -> put(JSONObject().put("id", id).put("name", nameOf(id))) }
            })
            state.put("wolfProposals", JSONArray().apply {
                aliveWolfIds().forEach { id ->
                    val targetId = wolfProposals[id]
                    put(JSONObject()
                        .put("id", id)
                        .put("name", nameOf(id))
                        .put("targetId", targetId ?: "")
                        .put("targetName", targetId?.let { nameOf(it) } ?: "")
                        .put("confirmed", targetId != null && wolfConfirmations[id] == targetId))
                }
            })
            state.put("myWolfProposalId", wolfProposals[playerId] ?: "")
            state.put("myWolfConfirmed", wolfProposals[playerId]?.let { wolfConfirmations[playerId] == it } ?: false)
            state.put("wolvesLocked", wolvesLocked)
            state.put("wolfAgreementRemainingMs", (wolfDeadlineAtMs - System.currentTimeMillis()).coerceAtLeast(0L))
        }
        if (me?.role == "SEER") {
            val targetId = seerTargets[playerId]
            val target = targetId?.let { players[it] }
            state.put("seerResult", seerReports[playerId] ?: "")
                .put("seerResultTargetId", targetId ?: "")
                .put("seerResultTargetName", target?.name ?: "")
                .put("seerResultRole", target?.role ?: "")
        }
        if (me?.role == "WITCH") {
            state.put("witchHealCharges", witchHealCharges)
            state.put("witchKillCharges", witchKillCharges)
            state.put("wolfTargetName", if (wolvesLocked) wolfTargetId?.let { nameOf(it) } ?: "" else "")
        }
        if (me?.role == "SALVATEUR") {
            state.put("canProtectSelf", !protectorSelfUsed)
            state.put("canProtectOthers", !protectorOtherUsed)
        }
        if (phase == "HUNTER_ACTION" && playerId == pendingHunterId) {
            state.put("mayChooseHunterTarget", true)
        }
        return state
    }

    private fun playerJson(player: Player) = JSONObject()
        .put("id", player.id)
        .put("name", player.name)
        .put("alive", player.alive)

    private fun aliveIds() = players.values.filter { it.alive }.map { it.id }
    private fun aliveWolfIds() = players.values.filter { it.alive && it.role == "WOLF" }.map { it.id }
    private fun aliveNonWolfIds() = players.values.filter { it.alive && it.role != "WOLF" }.map { it.id }
    private fun isAliveNonWolf(id: String) = players[id]?.let { it.alive && it.role != "WOLF" } == true
    private fun isAliveOther(from: String, target: String) = target != from && players[target]?.alive == true
    private fun nameOf(id: String) = players[id]?.name ?: "Unknown player"

    private fun beginChiefElection() {
        chiefCandidates.clear()
        chiefCandidates.addAll(players.values.filter { it.alive }.map { it.id }.shuffled().take(2))
        chiefVotes.clear()
        phase = "CHIEF_ELECTION"
        addEvent("Two players were drawn at random for the Village Chief election.")
    }

    private fun finishChiefElection() {
        val scores = voteCounts(chiefVotes, doubleChief = false)
        val best = scores.values.maxOrNull() ?: 0
        val tied = scores.filterValues { it == best }.keys.toList()
        chiefId = tied.randomOrNull() ?: chiefCandidates.firstOrNull()
        phase = "CHIEF_RESULT"
        addEvent("${nameOf(chiefId ?: "")} is Village Chief. Their vote counts twice and they choose the daytime voting order.")
    }

    private fun beginNight() {
        if (checkWinner()) return
        day++
        phase = "NIGHT_ACTIVITY"
        wolfProposals.clear()
        wolfConfirmations.clear()
        trustVotes.clear()
        seerTargets.clear()
        seerReports.clear()
        publicSeerReport = ""
        wolfTargetId = null
        wolvesLocked = false
        witchHealed = false
        witchPoisonTargetId = null
        witchTurnSubmitted = false
        protectorTargetId = null
        protectorTurnSubmitted = false
        nightDeaths.clear()
        nightDeathAnnouncements.clear()
        nightProtectionAnnouncements.clear()
        morningSummary = ""
        val now = System.currentTimeMillis()
        wolfDeadlineAtMs = now + WOLF_AGREEMENT_MS
        nightDeadlineAtMs = now + NIGHT_DURATION_MS
        lastVoteResult = ""
        if (aliveWolfIds().isEmpty() || aliveNonWolfIds().isEmpty()) checkWinner()
    }

    private fun nightActionsOpen(): Boolean =
        phase == "NIGHT_ACTIVITY" && System.currentTimeMillis() < nightDeadlineAtMs

    private fun wolfActionsOpen(): Boolean =
        nightActionsOpen() && !wolvesLocked && System.currentTimeMillis() < wolfDeadlineAtMs

    private fun lockWolfAgreement() {
        if (wolvesLocked) return
        val livingWolves = aliveWolfIds()
        val sharedTarget = livingWolves.firstOrNull()?.let { wolfProposals[it] }
        val agreedTarget = sharedTarget?.takeIf { candidate ->
            isAliveNonWolf(candidate) && livingWolves.all { wolfId ->
                wolfProposals[wolfId] == candidate && wolfConfirmations[wolfId] == candidate
            }
        }
        wolfTargetId = agreedTarget
        wolvesLocked = true
    }

    /** End the shared countdown as soon as every living night-role has submitted. */
    private fun finishNightEarlyIfReady() {
        if (phase != "NIGHT_ACTIVITY" || !wolvesLocked) return
        val living = aliveIds().mapNotNull { players[it] }
        val seerReady = living.filter { it.role == "SEER" }.all { seerTargets.containsKey(it.id) }
        val witchReady = living.filter { it.role == "WITCH" }.all { witchTurnSubmitted }
        val protectorReady = living.filter { it.role == "SALVATEUR" }.all { protectorTurnSubmitted }
        if (seerReady && witchReady && protectorReady) {
            nightDeadlineAtMs = System.currentTimeMillis()
        }
    }

    private fun resolveNight() {
        val target = wolfTargetId
        val resultLines = mutableListOf<String>()
        var savedTargetId: String? = null
        var savedCause = ""
        var savedLine = ""
        if (target != null) {
            val savedByWitch = witchHealed && target == wolfTargetId
            val savedByProtector = protectorTargetId == target
            when {
                savedByWitch && savedByProtector -> {
                    savedTargetId = target
                    savedCause = "WITCH_AND_SALVATEUR"
                    savedLine = "The Wolves attacked ${nameOf(target)}, but the Witch and the Salvateur saved them."
                }
                savedByWitch -> {
                    savedTargetId = target
                    savedCause = "WITCH"
                    savedLine = "The Wolves attacked ${nameOf(target)}, but the Witch healed them."
                }
                savedByProtector -> {
                    savedTargetId = target
                    savedCause = "SALVATEUR"
                    savedLine = "The Wolves attacked ${nameOf(target)}, but the Salvateur protected them."
                }
                else -> {
                    eliminate(target)
                    nightDeaths.add(target)
                    nightDeathAnnouncements[target] = "WOLVES"
                    resultLines.add("${nameOf(target)} was killed by the Wolves.")
                }
            }
        }
        val poison = witchPoisonTargetId
        if (poison != null) {
            val victimName = nameOf(poison)
            if (nightDeathAnnouncements[poison] == "WOLVES") {
                nightDeathAnnouncements[poison] = "WOLVES_AND_WITCH"
                val wolfDeathLine = "$victimName was killed by the Wolves."
                val lineIndex = resultLines.indexOf(wolfDeathLine)
                if (lineIndex >= 0) {
                    resultLines[lineIndex] = "$victimName was killed by the Wolves and the Witch."
                }
            } else if (players[poison]?.alive == true) {
                eliminate(poison)
                nightDeaths.add(poison)
                nightDeathAnnouncements[poison] = "WITCH"
                resultLines.add("$victimName was killed by the Witch's poison.")
            }
        }
        if (savedTargetId != null) {
            val protectionOutcome = if (poison == savedTargetId && nightDeathAnnouncements[poison] == "WITCH") {
                "WITCH_THEN_POISON"
            } else {
                savedCause
            }
            nightProtectionAnnouncements[savedTargetId] = protectionOutcome
            resultLines.add(0, savedLine)
        }
        if (resultLines.isEmpty()) resultLines.add("The village survived the night.")
        if (publicSeerReport.isNotBlank()) resultLines.add(publicSeerReport)
        morningSummary = resultLines.joinToString("\n")
        resultLines.forEach(::addEvent)

        pendingHunterId = nightDeaths.firstOrNull { players[it]?.role == "CHASSEUR" }
        if (checkWinner()) return
        if (pendingChiefSuccessorId != null) {
            chiefSuccessionReturnPhase = if (pendingHunterId != null) "HUNTER_ACTION" else "MORNING"
            phase = "CHIEF_SUCCESSION"
        } else if (pendingHunterId != null) {
            hunterReturnPhase = "MORNING"
            phase = "HUNTER_ACTION"
        } else {
            phase = "MORNING"
        }
    }

    private fun finishVillageVote() {
        val scores = voteCounts(villageVotes, doubleChief = true)
        val best = scores.values.maxOrNull() ?: 0
        val tied = scores.filterValues { it == best }.keys.toList()
        if (tied.size != 1) {
            lastVoteResult = "The village vote tied. No one is eliminated."
            addEvent(lastVoteResult)
            phase = "DAY_RESULT"
            return
        }
        val target = tied.single()
        eliminate(target)
        lastVoteResult = "${nameOf(target)} was voted out by the village."
        addEvent(lastVoteResult)
        pendingHunterId = target.takeIf { players[it]?.role == "CHASSEUR" }
        if (checkWinner()) return
        if (pendingChiefSuccessorId != null) {
            chiefSuccessionReturnPhase = if (pendingHunterId != null) "HUNTER_ACTION" else "DAY_RESULT"
            phase = "CHIEF_SUCCESSION"
        } else if (pendingHunterId != null) {
            hunterReturnPhase = "DAY_RESULT"
            phase = "HUNTER_ACTION"
        } else {
            phase = "DAY_RESULT"
        }
    }

    private fun continueAfterHunter() {
        if (checkWinner()) return
        if (pendingChiefSuccessorId != null) {
            chiefSuccessionReturnPhase = hunterReturnPhase
            phase = "CHIEF_SUCCESSION"
        } else {
            phase = hunterReturnPhase
        }
    }

    private fun eliminate(id: String) {
        if (id == chiefId) pendingChiefSuccessorId = id
        players[id]?.alive = false
    }

    private fun checkWinner(): Boolean {
        val wolves = aliveWolfIds().size
        val town = aliveIds().size - wolves
        if (wolves == 0) {
            phase = "GAME_OVER"
            lastVoteResult = "The Villagers win!"
            addEvent(lastVoteResult)
            return true
        }
        if (wolves >= town) {
            phase = "GAME_OVER"
            lastVoteResult = "The Wolves win!"
            addEvent(lastVoteResult)
            return true
        }
        return false
    }

    private fun winnerText(): String = when {
        phase != "GAME_OVER" -> ""
        aliveWolfIds().isEmpty() -> "The Villagers win!"
        else -> "The Wolves win!"
    }

    private fun maySetOrder(id: String, hostId: String): Boolean {
        val chief = chiefId
        return if (chief != null && players[chief]?.alive == true) id == chief else id == hostId
    }

    private fun actionDone(id: String): Boolean = when (phase) {
        "ROLE_REVEAL" -> ready.contains(id)
        "CHIEF_ELECTION" -> chiefVotes.containsKey(id)
        "CHIEF_SUCCESSION" -> id != pendingChiefSuccessorId
        "NIGHT_ACTIVITY" -> {
            val player = players[id]
            if (player?.alive != true) true
            else when (player.role) {
                "WOLF" -> wolfProposals[id]?.let { wolfConfirmations[id] == it } ?: false
                "SEER" -> seerTargets.containsKey(id)
                "WITCH" -> witchTurnSubmitted
                "SALVATEUR" -> protectorTurnSubmitted
                else -> trustVotes.containsKey(id)
            }
        }
        "HUNTER_ACTION" -> id != pendingHunterId
        "VILLAGE_VOTE" -> villageVotes.containsKey(id) || voterOrder.getOrNull(voteIndex) != id
        else -> false
    }

    private fun voteCountsJson(): JSONArray {
        if (phase == "CHIEF_ELECTION" || phase == "CHIEF_RESULT") {
            val counts = voteCounts(chiefVotes, doubleChief = false)
            return JSONArray().apply {
                chiefCandidates.forEach { id ->
                    put(JSONObject().put("id", id).put("name", nameOf(id)).put("count", counts[id] ?: 0))
                }
            }
        }
        return voteCountsJson(villageVotes, doubleChief = phase == "VILLAGE_VOTE" || phase == "DAY_RESULT")
    }

    private fun voteCountsJson(votes: Map<String, String>, doubleChief: Boolean): JSONArray {
        val counts = voteCounts(votes, doubleChief)
        return JSONArray().apply {
            counts.forEach { (targetId, count) ->
                put(JSONObject().put("id", targetId).put("name", nameOf(targetId)).put("count", count))
            }
        }
    }

    private fun voteCounts(votes: Map<String, String>, doubleChief: Boolean): Map<String, Int> {
        val counts = LinkedHashMap<String, Int>()
        votes.forEach { (voterId, targetId) ->
            val weight = if (doubleChief && voterId == chiefId && players[voterId]?.alive == true) 2 else 1
            counts[targetId] = (counts[targetId] ?: 0) + weight
        }
        return counts
    }

    private fun addEvent(event: String) {
        events.add(event)
        if (events.size > 200) events.removeAt(0)
    }

    private fun recordVoteAnnouncement(voterId: String, targetId: String, voteType: String) {
        voteAnnouncementSequence++
        latestVoteAnnouncement = JSONObject()
            .put("sequence", voteAnnouncementSequence)
            .put("voterId", voterId)
            .put("voterName", nameOf(voterId))
            .put("targetId", targetId)
            .put("targetName", nameOf(targetId))
            .put("voteType", voteType)
    }

    private fun roleTitle(role: String): String = when (role) {
        "WOLF" -> "Wolf"
        "VILLAGER" -> "Villager"
        "SEER" -> "Seer"
        "WITCH" -> "Witch"
        "SALVATEUR" -> "Salvateur"
        "CHASSEUR" -> "Chasseur"
        else -> role
    }

    private companion object {
        const val WOLF_AGREEMENT_MS = 30_000L
        const val NIGHT_DURATION_MS = 45_000L
    }
}
