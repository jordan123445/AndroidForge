# Wolves & Villagers — Red Wolf Android game

Includes a slowed animated opening credit for Made by Digital / Mahdi, a custom wolf-mask logo on the app icon, splash, and home screen, a full-screen red game interface, a nickname saved automatically as it is typed, and automatic room discovery for players on the same Wi-Fi or hotspot. Hosts create rooms; other players tap Join Room to search and connect. Debug builds also include local test bots: the host can fill the selected role setup with bots, which automatically play their turns.

The host configures optional Seer, Witch, Salvateur, and Chasseur roles, plus one or two Witch heal and poison charges. Roles are randomly shuffled each game. The game includes private Wolf proposals with unanimous confirmation, a quiet night puzzle for every player, a simultaneous no-effect trust choice for other players, private exact-role Seer results, Witch actions, Salvateur protections, morning reports, discussion, public vote-by-vote elimination, and the Chasseur's final shot. Players elect a Village Chief from two randomly selected candidates; the Chief's daytime vote counts twice and the Chief sets voting order. Role identities are private to each player, including after elimination. English and Arabic are supported with saved language preference and right-to-left layout for Arabic.

## Build the Android app

The project uses Android SDK Platform 35, Build Tools 35.0.0, and JDK 17 or newer.

From the workspace root, run:

```sh
pnpm android:debug
```

The installable debug APK is written to:

```text
RedWolfAndroid/app/build/outputs/apk/debug/app-debug.apk
```

You can also open the `RedWolfAndroid` folder in Android Studio, let it sync the Gradle project, and choose **Build > Build APK(s)**. On a new machine, accept the Android SDK licenses and install the SDK packages listed above when prompted.

## Test notes
Automatic discovery sends UDP broadcasts on port 8766 and the host listens for TCP connections on port 8765. Some phone hotspots isolate connected devices or block broadcasts, so joining depends on the network allowing local device communication. The host can resolve a stalled Wolf/trust night if a player disconnects or does not vote. Physical-device testing is still recommended, especially on the Samsung A15.


## Recent incremental UI/game updates
- Added a shared night-activity screen with a lightweight hidden-moon tile puzzle for every player.
- Added rounded, animated selection cards and a synchronized night countdown.
- Connected the Wolf UI to the existing host-authoritative proposal/confirmation actions. Wolves see only their pack's private proposals; changing a proposal clears their confirmation. The host still locks the agreement and ends the night on the existing deadlines.
- Added a staged private Seer result reveal using the exact target role from host game state. The result fields are included only in the Seer's state snapshot.
- Added a dawn-toned morning screen and a reminder for players to put phones down and discuss.
- Expanded Arabic translations for the updated screens and game messages.
