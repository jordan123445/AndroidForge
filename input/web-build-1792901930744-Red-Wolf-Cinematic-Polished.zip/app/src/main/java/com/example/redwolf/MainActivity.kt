package com.example.redwolf

import android.app.Activity
import android.app.Dialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.ColorDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.ToneGenerator
import android.media.AudioManager
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.os.Handler
import android.os.Looper
import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import org.json.JSONObject
import org.json.JSONArray
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket
import java.net.DatagramSocket
import java.net.DatagramPacket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 8, 18)
    private val panel = Color.rgb(18, 20, 34)
    private val accent = Color.rgb(255, 65, 83)
    private val lavender = Color.rgb(157, 103, 255)
    private val gold = Color.rgb(255, 190, 91)
    private val white = Color.rgb(248, 241, 239)
    private val muted = Color.rgb(174, 166, 184)
    private lateinit var root: LinearLayout
    private var playerName = "Player"
    private val prefs by lazy { getSharedPreferences("redwolf_settings", Context.MODE_PRIVATE) }
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var discovering = false
    private var playerId = UUID.randomUUID().toString()
    private var hostMode = false
    private var server: ServerSocket? = null
    private var hostWriter: PrintWriter? = null
    private var hostReaderThread: Thread? = null
    @Volatile private var clientSocket: Socket? = null
    @Volatile private var clientWriter: PrintWriter? = null
    private val peers = CopyOnWriteArrayList<Peer>()
    private val players = LinkedHashMap<String, String>()
    private val botIds = CopyOnWriteArrayList<String>()
    private val botScheduleLock = Any()
    private var botActionScheduled = false
    private var nextBotNumber = 1
    private var partyGame = PartyGame()
    private var wolfCount = 2
    private var salvateur = true
    private var chwafa = true
    private var witch = true
    private var chasseur = true
    private var witchKillsPerGame = 1
    private var witchHealsPerGame = 1
    private var roomStarted = false
    private var statusText = "Create a room or join a friend's room."
    private var nameInput: EditText? = null
    private var wolfSpinner: Spinner? = null
    private var witchKillSpinner: Spinner? = null
    private var witchHealSpinner: Spinner? = null
    private var salvateurCheck: CheckBox? = null
    private var chwafaCheck: CheckBox? = null
    private var witchCheck: CheckBox? = null
    private var chasseurCheck: CheckBox? = null
    private var lobbyText: TextView? = null
    private var joinStatusText: TextView? = null
    private var waitingStatusText: TextView? = null
    private var activeScrollView: ScrollView? = null
    private var savedScrollY: Int = 0

    private var localGameState: JSONObject? = null
    private var lastRenderedGameState = ""
    private var lastLocalPhase = ""
    private var roleCardVisible = true
    private val orderDraft = mutableListOf<String>()
    private var witchHealDraft = false
    private var witchPoisonDraftId: String? = null
    private var nightCountdownLabel: TextView? = null
    private var wolfCountdownLabel: TextView? = null
    private var nightCountdownLocalDeadline = 0L
    private var wolfCountdownLocalDeadline = 0L
    private var nightPuzzleDay = -1
    private var nightPuzzleFeedback = ""
    private var nightPuzzleSolved = false
    private var nightPuzzleSymbols: List<String> = emptyList()
    private val nightPuzzleMatched = mutableSetOf<Int>()
    private var nightPuzzleFirstPick: Int? = null
    private val nightPuzzleTileViews = mutableListOf<Button>()
    private var nightPuzzleResetRunnable: Runnable? = null
    private var seerRevealTargetId = ""
    private var seerRevealRoleVisible = false
    private var seerRevealDismissedTargetId = ""
    private var seerAnnouncementTargetId = ""
    private var seerRevealRunnable: Runnable? = null
    private var announcementDialog: Dialog? = null
    private val pendingGameAnnouncements = java.util.ArrayDeque<GameAnnouncement>()
    private var lastVoteAnnouncementSequence = -1
    private var lastWolfApprovalPromptKey = ""
    private var deathSoundTrack: AudioTrack? = null
    private var scheduledWolfDeadlineAt = 0L
    private var scheduledNightDeadlineAt = 0L
    private var wolfDeadlineTask: Runnable? = null
    private var nightDeadlineTask: Runnable? = null
    private val nightCountdownRunnable = object : Runnable {
        override fun run() {
            val countdown = nightCountdownLabel ?: return
            val now = android.os.SystemClock.elapsedRealtime()
            val remaining = (nightCountdownLocalDeadline - now).coerceAtLeast(0L)
            countdown.text = UiText.localize("Night ends in ${remaining / 1000L}s", isArabicUi())
            wolfCountdownLabel?.let { wolfLabel ->
                val wolfRemaining = (wolfCountdownLocalDeadline - now).coerceAtLeast(0L)
                wolfLabel.text = UiText.localize("Wolf agreement closes in ${wolfRemaining / 1000L}s", isArabicUi())
            }
            if (remaining > 0L && localGameState?.optString("phase") == "NIGHT_ACTIVITY") {
                mainHandler.postDelayed(this, 1_000L)
            } else {
                nightCountdownLabel = null
                wolfCountdownLabel = null
            }
        }
    }

    private data class Peer(val id: String, val name: String, val socket: Socket, val writer: PrintWriter)
    private data class GamePlayer(val id: String, val name: String, val alive: Boolean)
    private data class ChoiceOption(val id: String, val label: String)
    private data class GameAnnouncement(
        val title: String,
        val message: String,
        val detail: String?,
        val symbol: String,
        val highlightColor: Int,
        val details: List<Pair<String, String>>,
        val playDeathSound: Boolean,
        val onDismiss: (() -> Unit)?,
    )

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        applyImmersiveMode()
        playerName = prefs.getString("player_name", "Player") ?: "Player"
        showSplash()
    }

    @Suppress("DEPRECATION")
    private fun applyImmersiveMode() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveMode()
    }

    private fun showSplash() {
        setup("", splash = true)
        root.gravity = Gravity.CENTER
        val made = label("A DARK FANTASY SOCIAL GAME", 12, muted, true)
            .apply { gravity = Gravity.CENTER; letterSpacing = 0.12f }
        val mahdi = label("RED WOLF", 38, accent, true)
            .apply { gravity = Gravity.CENTER; letterSpacing = 0.08f }
        space(14)
        val logoMark = label("🐺", 68, white, true).apply {
            gravity = Gravity.CENTER
            scaleX = 0.72f
            scaleY = 0.72f
        }
        val logo = label("TRUST NO ONE", 17, gold, true)
            .apply { gravity = Gravity.CENTER; letterSpacing = 0.16f }
        val tagline = label("THE MOON REMEMBERS EVERYTHING", 11, muted, true)
            .apply { gravity = Gravity.CENTER }
        reveal(made, 450)
        reveal(mahdi, 1250)
        reveal(logoMark, 2400, pop = true)
        reveal(logo, 2800, pop = true)
        reveal(tagline, 3600)
        mainHandler.postDelayed({ if (!isFinishing) showHome() }, 5600)
    }

    private fun reveal(view: View, delayMs: Long, pop: Boolean = false) {
        view.alpha = 0f
        mainHandler.postDelayed({
            if (isFinishing) return@postDelayed
            view.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(if (pop) 1250L else 950L)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }, delayMs)
    }

    private fun savePlayerName(name: String) {
        playerName = name.trim().ifBlank { "Player" }.take(24)
        prefs.edit().putString("player_name", playerName).apply()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun isArabicUi(): Boolean = prefs.getString("ui_language", "ar") == "ar"

    private fun addLogo(sizeDp: Int) {
        val image = ImageView(this).apply {
            setImageResource(R.drawable.wolves_villagers_logo)
            contentDescription = "Wolves & Villagers logo"
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        root.addView(
            image,
            LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
            },
        )
    }

    private fun setup(title: String, splash: Boolean = false) {
        // Keep the player at the same position when live game updates rebuild the screen.
        activeScrollView?.let { savedScrollY = it.scrollY }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
            setBackgroundColor(Color.TRANSPARENT)
            layoutDirection = if (isArabicUi()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            clipToPadding = false
            setOnScrollChangeListener { _, y, _, _, _ -> savedScrollY = y }
            addView(root, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        activeScrollView = scroll
        val scene = FrameLayout(this)
        scene.addView(AtmosphereView(this), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        scene.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(scene, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        scroll.post { scroll.scrollTo(0, savedScrollY.coerceAtLeast(0)) }
        if (title.isNotBlank()) {
            val header = label("☾  $title  ☽", 26, gold, true)
            header.gravity = Gravity.CENTER
            header.setPadding(dp(8), dp(10), dp(8), dp(8))
            header.background = ornateSurface(Color.rgb(31, 14, 25), accent)
            label("RED WOLF  •  TRUST NO ONE", 11, muted, true).apply { gravity = Gravity.CENTER }
            space(16)
        }
    }

    private fun label(text: String, size: Int, color: Int = white, bold: Boolean = false): TextView {
        val v = TextView(this).apply {
            this.text = UiText.localize(text, isArabicUi())
            textSize = size.toFloat()
            setTextColor(color)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 5, 0, 5)
        }
        root.addView(v)
        return v
    }

    private fun space(h: Int) { root.addView(View(this), LinearLayout.LayoutParams(1, h)) }

    private fun nightOutcomeDetails(state: JSONObject): List<Pair<String, String>> {
        val result = mutableListOf<Pair<String, String>>()
        val publicSeerReport = state.optString("publicSeerReport").trim()
        if (publicSeerReport.isNotBlank()) {
            result.add("SEER'S VISION" to publicSeerReport.uppercase(java.util.Locale.ROOT))
        }
        val deaths = state.optJSONArray("nightDeathAnnouncements") ?: JSONArray()
        for (index in 0 until deaths.length()) {
            val item = deaths.optJSONObject(index) ?: continue
            val name = item.optString("playerName")
            if (name.isBlank()) continue
            val cause = when (item.optString("cause")) {
                "WOLVES" -> "KILLED BY THE WOLVES"
                "WITCH" -> "KILLED BY THE WITCH"
                "WOLVES_AND_WITCH" -> "KILLED BY THE WOLVES AND THE WITCH"
                else -> continue
            }
            result.add(name to cause)
        }
        val protections = state.optJSONArray("nightProtectionAnnouncements") ?: JSONArray()
        for (index in 0 until protections.length()) {
            val item = protections.optJSONObject(index) ?: continue
            val name = item.optString("playerName")
            if (name.isBlank()) continue
            val cause = when (item.optString("cause")) {
                "WITCH" -> "SAVED BY THE WITCH"
                "SALVATEUR" -> "PROTECTED BY THE SALVATEUR"
                "WITCH_AND_SALVATEUR" -> "SAVED BY THE WITCH AND THE SALVATEUR"
                "WITCH_THEN_POISON" -> "HEALED BY THE WITCH, THEN KILLED BY POISON"
                else -> continue
            }
            result.add(name to cause)
        }
        return result
    }

    private fun showGameAnnouncement(
        title: String,
        message: String,
        detail: String? = null,
        symbol: String,
        highlightColor: Int,
        details: List<Pair<String, String>> = emptyList(),
        playDeathSound: Boolean = false,
        onDismiss: (() -> Unit)? = null,
    ) {
        pendingGameAnnouncements.addLast(
            GameAnnouncement(title, message, detail, symbol, highlightColor, details, playDeathSound, onDismiss),
        )
        showNextGameAnnouncement()
    }

    private fun showNextGameAnnouncement() {
        if (isFinishing || isDestroyed || announcementDialog?.isShowing == true) return
        val announcement = pendingGameAnnouncements.pollFirst() ?: return
        displayGameAnnouncement(announcement)
    }

    private fun displayGameAnnouncement(announcement: GameAnnouncement) {
        val title = announcement.title
        val message = announcement.message
        val detail = announcement.detail
        val symbol = announcement.symbol
        val highlightColor = announcement.highlightColor
        val details = announcement.details

        val dialog = Dialog(this)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(22), dp(24), dp(20))
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                cornerRadius = dp(26).toFloat()
                setColor(Color.rgb(18, 24, 43))
                setStroke(dp(2), highlightColor)
            }
        }
        val emblem = TextView(this).apply {
            text = symbol
            textSize = 44f
            gravity = Gravity.CENTER
            setTextColor(highlightColor)
            setPadding(0, 0, 0, dp(4))
        }
        card.addView(emblem, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
        ))
        val heading = TextView(this).apply {
            text = UiText.localize(title, isArabicUi())
            textSize = 14f
            setTextColor(highlightColor)
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
            letterSpacing = 0.08f
            setPadding(0, dp(4), 0, dp(10))
        }
        card.addView(heading)
        val mainMessage = TextView(this).apply {
            text = UiText.localize(message, isArabicUi())
            textSize = 22f
            setTextColor(white)
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setPadding(0, 0, 0, if (detail != null || details.isNotEmpty()) dp(10) else dp(16))
        }
        card.addView(mainMessage)

        detail?.let {
            val detailText = TextView(this).apply {
                text = UiText.localize(it, isArabicUi())
                textSize = 15f
                setTextColor(muted)
                gravity = Gravity.CENTER
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
                setPadding(0, 0, 0, dp(10))
            }
            card.addView(detailText)
        }

        details.forEach { (name, cause) ->
            val saved = cause.startsWith("SAVED") || cause.startsWith("PROTECTED")
            val detailCard = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    cornerRadius = dp(16).toFloat()
                    setColor(if (saved) Color.rgb(21, 44, 42) else Color.rgb(36, 27, 43))
                    setStroke(dp(1), if (saved) Color.rgb(61, 133, 113) else Color.rgb(141, 60, 74))
                }
            }
            val playerName = TextView(this).apply {
                text = name
                textSize = 19f
                setTextColor(white)
                gravity = Gravity.CENTER
                setTypeface(null, android.graphics.Typeface.BOLD)
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            }
            val killer = TextView(this).apply {
                text = UiText.localize(cause, isArabicUi())
                textSize = 13f
                setTextColor(if (saved) Color.rgb(120, 225, 188) else Color.rgb(255, 137, 146))
                gravity = Gravity.CENTER
                setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(0, dp(3), 0, 0)
            }
            detailCard.addView(playerName)
            detailCard.addView(killer)
            card.addView(detailCard, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { bottomMargin = dp(8) })
        }

        val continueButton = Button(this).apply {
            text = UiText.localize("CONTINUE", isArabicUi())
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.rgb(16, 20, 35))
            minHeight = dp(52)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                cornerRadius = dp(16).toFloat()
                setColor(highlightColor)
            }
            setOnClickListener { dialog.dismiss() }
        }
        card.addView(continueButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
        ).apply { topMargin = dp(8) })

        card.alpha = 0f
        card.scaleX = 0.9f
        card.scaleY = 0.9f
        card.translationY = dp(18).toFloat()
        dialog.setContentView(card)
        dialog.setCancelable(true)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        dialog.window?.attributes = dialog.window?.attributes?.apply { dimAmount = 0.78f }
        dialog.setOnDismissListener {
            if (announcementDialog === dialog) announcementDialog = null
            if (!isFinishing && !isDestroyed) {
                announcement.onDismiss?.invoke()
                mainHandler.postDelayed({ showNextGameAnnouncement() }, 140L)
            }
        }
        announcementDialog = dialog
        dialog.show()
        dialog.window?.setLayout(
            dp((resources.configuration.screenWidthDp - 32).coerceAtMost(480)),
            ViewGroup.LayoutParams.WRAP_CONTENT,
        )

        val motionScale = android.provider.Settings.Global.getFloat(
            contentResolver,
            android.provider.Settings.Global.ANIMATOR_DURATION_SCALE,
            1f,
        )
        if (motionScale > 0f) {
            card.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setDuration(420L)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        } else {
            card.alpha = 1f
            card.scaleX = 1f
            card.scaleY = 1f
            card.translationY = 0f
        }
        if (announcement.playDeathSound) playNightDeathSound()
    }

    private fun playNightDeathSound() {
        try {
            deathSoundTrack?.let { previous ->
                if (previous.playState == AudioTrack.PLAYSTATE_PLAYING) previous.stop()
                previous.release()
            }
            deathSoundTrack = null

            val sampleRate = 22_050
            val samples = ShortArray(sampleRate * 3 / 4)
            var filteredNoise = 0.0
            samples.indices.forEach { index ->
                val time = index.toDouble() / sampleRate
                val noise = kotlin.random.Random.Default.nextDouble(-1.0, 1.0)
                filteredNoise = filteredNoise * 0.78 + noise * 0.22

                val sweepPosition = (time - 0.15) / 0.11
                val sweep = filteredNoise * exp(-sweepPosition * sweepPosition) * 0.22
                val impactTime = (time - 0.32).coerceAtLeast(0.0)
                val impactEnvelope = if (time >= 0.32) exp(-impactTime * 16.0) else 0.0
                val impact = (
                    sin(2.0 * PI * 72.0 * impactTime) * 0.18 +
                        sin(2.0 * PI * 126.0 * impactTime) * 0.06 +
                        filteredNoise * 0.07
                    ) * impactEnvelope
                val value = ((sweep + impact) * 0.55).coerceIn(-0.35, 0.35)
                samples[index] = (value * Short.MAX_VALUE).toInt().toShort()
            }

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build(),
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build(),
                )
                .setBufferSizeInBytes(samples.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            if (track.state != AudioTrack.STATE_INITIALIZED || track.write(samples, 0, samples.size) <= 0) {
                track.release()
                return
            }
            track.setVolume(0.28f)
            deathSoundTrack = track
            track.play()
            mainHandler.postDelayed({
                if (deathSoundTrack === track) {
                    if (track.playState == AudioTrack.PLAYSTATE_PLAYING) track.stop()
                    track.release()
                    deathSoundTrack = null
                }
            }, 1_200L)
        } catch (error: Exception) {
            deathSoundTrack?.let { track ->
                try {
                    if (track.playState == AudioTrack.PLAYSTATE_PLAYING) track.stop()
                    track.release()
                } catch (_: Exception) {}
            }
            deathSoundTrack = null
            android.util.Log.w("WolvesAndVillagers", "Could not play the night death sound.", error)
        }
    }

    private fun themedActionButton(text: String, tint: Int, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = UiText.localize(text, isArabicUi())
            textSize = 15f; isAllCaps = false; setTextColor(white)
            minHeight = dp(50); stateListAnimator = null
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                cornerRadius = dp(15).toFloat()
                setColor(Color.rgb(22, 19, 34))
                setStroke(dp(2), tint)
            }
            setOnClickListener { playUiClickSound(); action() }
        }
        root.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) })
    }

    private fun playUiClickSound() {
        try {
            val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 22)
            tone.startTone(ToneGenerator.TONE_PROP_ACK, 45)
            mainHandler.postDelayed({ try { tone.release() } catch (_: Exception) {} }, 100L)
        } catch (_: Exception) { }
    }

    private fun showCompactConfirmation(
        title: String,
        message: String,
        positive: String,
        negative: String = "NO",
        onPositive: () -> Unit,
    ) {
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setNegativeButton(negative, null)
            .setPositiveButton(positive) { _, _ -> onPositive() }
            .create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.rgb(22, 13, 28)))
            dialog.window?.setLayout(dp(292), ViewGroup.LayoutParams.WRAP_CONTENT)
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE)?.setTextColor(gold)
            dialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE)?.setTextColor(muted)
        }
        dialog.show()
        dialog.window?.setLayout(dp(292), ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.window?.attributes = dialog.window?.attributes?.apply { dimAmount = 0.45f }
        playUiClickSound()
    }

    private fun button(text: String, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = UiText.localize(text, isArabicUi())
            setTextColor(white)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                cornerRadius = dp(17).toFloat()
                orientation = android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT
                colors = intArrayOf(Color.rgb(43, 17, 30), Color.rgb(20, 22, 38))
                setStroke(dp(1), Color.rgb(157, 54, 72))
            }
            isAllCaps = false
            textSize = 16f
            letterSpacing = 0.025f
            minHeight = dp(54)
            stateListAnimator = null
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setOnClickListener {
                playUiClickSound()
                val motionScale = android.provider.Settings.Global.getFloat(
                    contentResolver,
                    android.provider.Settings.Global.ANIMATOR_DURATION_SCALE,
                    1f,
                )
                if (motionScale > 0f) {
                    animate().scaleX(1.04f).scaleY(1.04f).setDuration(90L).withEndAction {
                        animate().scaleX(1f).scaleY(1f).setDuration(110L).withEndAction { action() }.start()
                    }.start()
                } else {
                    action()
                }
            }
        }
        root.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(10)
        })
    }

    private fun input(hint: String, value: String = ""): EditText {
        val e = EditText(this).apply {
            this.hint = UiText.localize(hint, isArabicUi())
            setText(value)
            setTextColor(white)
            setHintTextColor(muted)
            setSingleLine(true)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = ornateSurface(Color.rgb(17, 20, 33), Color.rgb(75, 57, 76))
        }
        root.addView(e, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(10)
        })
        return e
    }

    private fun ornateSurface(fill: Int, stroke: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(16).toFloat()
            setColor(fill)
            setStroke(dp(1), stroke)
        }

    /** Static custom-drawn scene: atmospheric, lightweight, and offline-safe. */
    private inner class AtmosphereView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            paint.shader = LinearGradient(0f, 0f, w, h, intArrayOf(Color.rgb(5, 8, 20), Color.rgb(24, 10, 29), Color.rgb(5, 10, 20)), null, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, h, paint); paint.shader = null
            // Red moon with a soft halo.
            paint.color = Color.argb(25, 255, 35, 65)
            canvas.drawCircle(w * .82f, h * .13f, dp(94).toFloat(), paint)
            paint.color = Color.argb(45, 255, 42, 67)
            canvas.drawCircle(w * .82f, h * .13f, dp(65).toFloat(), paint)
            paint.color = Color.rgb(143, 34, 54)
            canvas.drawCircle(w * .82f, h * .13f, dp(43).toFloat(), paint)
            paint.color = Color.rgb(202, 71, 83)
            canvas.drawCircle(w * .82f - dp(9), h * .13f - dp(8), dp(31).toFloat(), paint)
            paint.color = Color.argb(70, 22, 8, 24)
            canvas.drawCircle(w * .82f + dp(13), h * .13f + dp(12), dp(29).toFloat(), paint)
            // Small fixed stars, deliberately no animation to protect low-end devices.
            for (i in 0 until 42) {
                val x = ((i * 73 + 19) % 997) / 997f * w
                val y = ((i * 131 + 37) % 541) / 541f * h * .72f
                paint.color = Color.argb(80 + (i * 13 % 150), 220, 202, 220)
                canvas.drawCircle(x, y, dp(if (i % 7 == 0) 2 else 1).toFloat(), paint)
            }
            // Layered distant ridges and foreground pine silhouettes.
            val ridge = Path().apply { moveTo(0f, h * .69f); lineTo(w*.15f,h*.54f); lineTo(w*.29f,h*.68f); lineTo(w*.47f,h*.51f); lineTo(w*.65f,h*.68f); lineTo(w*.82f,h*.56f); lineTo(w,h*.68f); lineTo(w,h); lineTo(0f,h); close() }
            paint.color = Color.rgb(12, 17, 32); canvas.drawPath(ridge, paint)
            val ridge2 = Path().apply { moveTo(0f,h*.79f); lineTo(w*.2f,h*.67f); lineTo(w*.36f,h*.8f); lineTo(w*.61f,h*.66f); lineTo(w*.8f,h*.8f); lineTo(w,h*.7f); lineTo(w,h); lineTo(0f,h); close() }
            paint.color = Color.rgb(7, 12, 23); canvas.drawPath(ridge2, paint)
            paint.color = Color.rgb(10, 11, 19)
            for (i in 0..8) {
                val x = (i * w / 8f)
                val base = h * (0.89f + (i % 3) * .035f)
                val top = base - h * (.09f + (i % 4) * .018f)
                val tree = Path().apply { moveTo(x, base); lineTo(x-dp(15), base-dp(22)); lineTo(x-dp(7), base-dp(22)); lineTo(x-dp(19), top); lineTo(x, top-dp(10)); lineTo(x+dp(19), top); lineTo(x+dp(7), base-dp(22)); lineTo(x+dp(15), base-dp(22)); close() }
                canvas.drawPath(tree, paint)
            }
        }
    }

    private fun showHome() {
        setup("RED WOLF")
        label("A village. A curse. One night can change everything.", 15, white, true).apply { gravity = Gravity.CENTER }
        space(8)
        addLogo(108)
        space(14)
        label("ENTER THE VILLAGE", 13, gold, true).apply { gravity = Gravity.CENTER }
        label("YOUR NAME", 12, muted, true)
        nameInput = input("Enter your name", playerName).also { edit ->
            edit.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                override fun afterTextChanged(s: Editable?) {
                    savePlayerName(s?.toString().orEmpty())
                }
            })
        }
        button("CREATE ROOM") {
            savePlayerName(nameInput?.text?.toString().orEmpty())
            createRoom()
        }
        button("JOIN ROOM") {
            savePlayerName(nameInput?.text?.toString().orEmpty())
            showJoin()
            discoverRoom()
        }
        button(if (isArabicUi()) "English" else "العربية") {
            prefs.edit().putString("ui_language", if (isArabicUi()) "en" else "ar").apply()
            showHome()
        }
        space(10)
        label("PLAY TOGETHER • SAME WI-FI OR HOTSPOT • NO INTERNET REQUIRED", 11, muted, true).apply { gravity = Gravity.CENTER }
    }

    private fun createRoom() {
        hostMode = true
        roomStarted = false
        partyGame = PartyGame()
        botIds.clear()
        nextBotNumber = 1
        players.clear()
        players[playerId] = playerName
        thread {
            try {
                server = ServerSocket(8765)
                startDiscoveryResponder()
                runOnUiThread {
                    statusText = "Room ready. Friends can find it automatically."
                    showHostLobby()
                }
                while (!server!!.isClosed) {
                    val socket = server!!.accept()
                    thread { handleNewPeer(socket) }
                }
            } catch (_: Exception) { }
        }
    }

    private fun handleNewPeer(socket: Socket) {
        var joinedPlayerId: String? = null
        try {
            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            val writer = PrintWriter(socket.getOutputStream(), true)
            val first = JSONObject(reader.readLine())
            if (first.optString("type") != "join") { socket.close(); return }
            val id = first.optString("id")
            if (roomStarted || partyGame.isStarted) {
                writer.println(JSONObject().put("type", "error").put("message", "This game has already started.").toString())
                socket.close()
                return
            }
            val name = first.optString("name", "Player").take(24)
            val peer = Peer(id, name, socket, writer)
            peers.add(peer)
            synchronized(players) { players[id] = name }
            joinedPlayerId = id
            writer.println(JSONObject().put("type", "welcome").put("id", id).toString())
            broadcastLobby()
            runOnUiThread { if (hostMode && !roomStarted) { captureHostSettings(); showHostLobby() } }
            while (true) {
                val line = reader.readLine() ?: break
                val msg = JSONObject(line)
                when (msg.optString("type")) {
                    "ping" -> writer.println("{\"type\":\"pong\"}")
                    "action" -> {
                        if (partyGame.handle(id, playerId, msg)) publishGameState()
                    }
                }
            }
        } catch (_: Exception) {
        } finally {
            peers.removeAll { it.socket == socket }
            val disconnectedId = joinedPlayerId
            if (disconnectedId != null && !partyGame.isStarted) {
                synchronized(players) { players.remove(disconnectedId) }
            }
            try { socket.close() } catch (_: Exception) {}
            if (disconnectedId != null && !partyGame.isStarted) broadcastLobby()
            runOnUiThread { if (hostMode && !roomStarted) { captureHostSettings(); showHostLobby() } }
        }
    }

    private fun broadcastLobby() {
        val names = JSONArray()
        synchronized(players) { players.values.forEach { names.put(it) } }
        val msg = JSONObject().put("type", "lobby").put("players", names).toString()
        peers.forEach { try { it.writer.println(msg) } catch (_: Exception) {} }
    }

    private fun showHostLobby() {
        setup("ROOM LOBBY")
        label("Room ready. Friends on the same Wi-Fi or hotspot can join automatically.", 14, muted)
        space(10)
        label("WOLF COUNT", 14, muted, true)
        wolfSpinner = Spinner(this)
        val wolfOptions = (2..5).map { "$it wolves" }
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, wolfOptions) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
                (super.getView(position, convertView, parent) as TextView).apply {
                    setTextColor(gold); textSize = 17f; setPadding(dp(14), dp(10), dp(14), dp(10))
                }
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View =
                (super.getDropDownView(position, convertView, parent) as TextView).apply {
                    setTextColor(white); textSize = 16f; setBackgroundColor(Color.rgb(28, 17, 34)); setPadding(dp(16), dp(12), dp(16), dp(12))
                }
        }.also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        wolfSpinner!!.adapter = adapter
        wolfSpinner!!.background = ornateSurface(Color.rgb(27, 17, 35), gold)
        wolfSpinner!!.setSelection(wolfCount - 2)
        root.addView(wolfSpinner)
        salvateurCheck = check("Salvateur", salvateur)
        chwafaCheck = check("Chwafa (Seer)", chwafa)
        witchCheck = check("Witch", witch)
        chasseurCheck = check("Chasseur (Hunter)", chasseur)
        label("WITCH POTIONS", 13, muted, true)
        label("Kill charges per game", 12, muted)
        witchKillSpinner = countSpinner(witchKillsPerGame)
        label("Heal charges per game", 12, muted)
        witchHealSpinner = countSpinner(witchHealsPerGame)
        if (isDebugBuild()) {
            space(8)
            label("LOCAL TEST BOTS", 13, Color.rgb(255, 204, 117), true)
            label("Bots are only added to this test room and play their turns automatically.", 12, muted)
            button("ADD TEST BOTS TO FILL THE ROOM") { addTestBots() }
            if (botIds.isNotEmpty()) button("REMOVE TEST BOTS") { removeTestBots() }
        }
        space(12)
        label("PLAYERS", 14, muted, true)
        lobbyText = label(playerNames().joinToString("\n").ifBlank { "Waiting for players…" }, 16, white)
        label("Roles are shuffled each game and kept secret from the lobby.", 12, muted)
        button("START GAME") { startGame() }
        button("BACK TO HOME") { closeServer(); showHome() }
    }

    private fun isDebugBuild(): Boolean =
        applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE != 0

    private fun addTestBots() {
        if (!isDebugBuild() || partyGame.isStarted) return
        captureHostSettings()
        val specialRoles = listOf(salvateur, chwafa, witch, chasseur).count { it }
        val minimumPlayers = wolfCount + specialRoles + 1
        val currentCount = synchronized(players) { players.size }
        val countToAdd = (minimumPlayers - currentCount).coerceAtLeast(0)
        if (countToAdd == 0) {
            Toast.makeText(this, "This room already has enough players for the selected roles.", Toast.LENGTH_LONG).show()
            return
        }
        repeat(countToAdd) {
            val id = "test-bot-${UUID.randomUUID()}"
            val name = "TEST BOT ${nextBotNumber++}"
            synchronized(players) { players[id] = name }
            botIds.add(id)
        }
        broadcastLobby()
        showHostLobby()
    }

    private fun removeTestBots() {
        if (partyGame.isStarted) return
        val ids = botIds.toList()
        botIds.clear()
        synchronized(players) { ids.forEach { players.remove(it) } }
        broadcastLobby()
        showHostLobby()
    }

    private fun countSpinner(selectedCount: Int): Spinner {
        return Spinner(this).apply {
            adapter = object : ArrayAdapter<String>(this@MainActivity, android.R.layout.simple_spinner_item, listOf("1 use", "2 uses")) {
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
                    (super.getView(position, convertView, parent) as TextView).apply {
                        setTextColor(gold); textSize = 16f; setPadding(dp(14), dp(9), dp(14), dp(9))
                    }
                override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View =
                    (super.getDropDownView(position, convertView, parent) as TextView).apply {
                        setTextColor(white); setBackgroundColor(Color.rgb(28, 17, 34)); setPadding(dp(16), dp(12), dp(16), dp(12))
                    }
            }.also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            background = ornateSurface(Color.rgb(27, 17, 35), lavender)
            setSelection((selectedCount - 1).coerceIn(0, 1))
            root.addView(this)
        }
    }

    private fun captureHostSettings() {
        wolfCount = (wolfSpinner?.selectedItemPosition ?: (wolfCount - 2)) + 2
        salvateur = salvateurCheck?.isChecked ?: salvateur
        chwafa = chwafaCheck?.isChecked ?: chwafa
        witch = witchCheck?.isChecked ?: witch
        chasseur = chasseurCheck?.isChecked ?: chasseur
        witchKillsPerGame = (witchKillSpinner?.selectedItemPosition ?: (witchKillsPerGame - 1)) + 1
        witchHealsPerGame = (witchHealSpinner?.selectedItemPosition ?: (witchHealsPerGame - 1)) + 1
    }

    private fun check(text: String, checked: Boolean): CheckBox {
        return CheckBox(this).apply {
            this.text = UiText.localize(text, isArabicUi())
            setTextColor(white)
            isChecked = checked
            buttonTintList = android.content.res.ColorStateList.valueOf(accent)
            layoutDirection = if (isArabicUi()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
            root.addView(this)
        }
    }

    private fun playerNames(): List<String> = synchronized(players) { players.values.toList() }

    private fun startGame() {
        captureHostSettings()
        val enabledRoles = buildSet {
            if (salvateur) add("SALVATEUR")
            if (chwafa) add("SEER")
            if (witch) add("WITCH")
            if (chasseur) add("CHASSEUR")
        }
        val names = synchronized(players) { LinkedHashMap(players) }
        val error = partyGame.start(names, wolfCount, enabledRoles, witchKillsPerGame, witchHealsPerGame)
        if (error != null) {
            Toast.makeText(this, error, Toast.LENGTH_LONG).show()
            return
        }
        roomStarted = true
        roleCardVisible = true
        publishGameState()
    }

    private fun showJoin() {
        setup("JOIN ROOM")
        label("Searching this Wi-Fi or hotspot for an open room.", 15, muted)
        statusText = "Looking for a room…"
        joinStatusText = label(statusText, 16, white, true)
        space(12)
        button("SEARCH AGAIN") { discoverRoom() }
        button("BACK") { discovering = false; showHome() }
    }

    private fun startDiscoveryResponder() {
        thread(name = "RedWolfDiscoveryHost") {
            var ds: DatagramSocket? = null
            try {
                ds = DatagramSocket(8766, InetAddress.getByName("0.0.0.0"))
                ds.broadcast = true
                val buffer = ByteArray(256)
                while (hostMode && !ds.isClosed) {
                    val packet = DatagramPacket(buffer, buffer.size)
                    ds.receive(packet)
                    val msg = String(packet.data, packet.offset, packet.length).trim()
                    if (msg == "REDWOLF_DISCOVER") {
                        val response = "REDWOLF_ROOM|Red Wolf Room"
                        val data = response.toByteArray()
                        ds.send(DatagramPacket(data, data.size, packet.address, packet.port))
                    }
                }
            } catch (_: Exception) { } finally { try { ds?.close() } catch (_: Exception) {} }
        }
    }

    private fun discoverRoom() {
        if (discovering) return
        discovering = true
        statusText = "Looking for a room…"
        runOnUiThread { joinStatusText?.text = statusText }
        thread(name = "RedWolfDiscoveryClient") {
            var ds: DatagramSocket? = null
            try {
                ds = DatagramSocket()
                ds.broadcast = true
                ds.soTimeout = 1800
                val request = "REDWOLF_DISCOVER".toByteArray()
                val broadcast = InetAddress.getByName("255.255.255.255")
                repeat(5) {
                    if (!discovering) return@repeat
                    ds.send(DatagramPacket(request, request.size, broadcast, 8766))
                    val buffer = ByteArray(512)
                    val response = DatagramPacket(buffer, buffer.size)
                    try {
                        ds.receive(response)
                        val text = String(response.data, response.offset, response.length).trim()
                        if (text.startsWith("REDWOLF_ROOM|")) {
                            val ip = response.address.hostAddress ?: return@thread
                            discovering = false
                            runOnUiThread {
                                statusText = "Room found. Joining…"
                                joinStatusText?.text = statusText
                                connectToHost(ip)
                            }
                            return@thread
                        }
                    } catch (_: SocketTimeoutException) { }
                }
                runOnUiThread {
                    if (discovering) {
                        statusText = "No room found. Make sure someone created a room and both phones share the same Wi-Fi or hotspot."
                        joinStatusText?.text = statusText
                    }
                }
            } catch (_: Exception) {
                runOnUiThread {
                    statusText = "Room search failed. Check that both phones are on the same Wi-Fi or hotspot."
                    joinStatusText?.text = statusText
                }
            } finally { discovering = false; try { ds?.close() } catch (_: Exception) {} }
        }
    }

    private fun connectToHost(ip: String) {
        statusText = "Connecting to room…"
        joinStatusText?.text = statusText
        thread {
            try {
                val socket = Socket(ip, 8765)
                val writer = PrintWriter(socket.getOutputStream(), true)
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                clientSocket = socket
                clientWriter = writer
                writer.println(JSONObject().put("type", "join").put("id", playerId).put("name", playerName).toString())
                runOnUiThread { showWaiting() }
                while (true) {
                    val line = reader.readLine() ?: break
                    val msg = JSONObject(line)
                    when (msg.optString("type")) {
                        "lobby" -> {
                            val names = msg.optJSONArray("players")
                            val count = names?.length() ?: 0
                            runOnUiThread {
                                statusText = "Connected. Players in room: $count"
                                waitingStatusText?.text = statusText
                            }
                        }
                        "gameState" -> runOnUiThread { acceptGameState(msg) }
                        "error" -> runOnUiThread {
                            Toast.makeText(this, msg.optString("message", "Unable to join this room."), Toast.LENGTH_LONG).show()
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setup("CONNECTION FAILED")
                    label("Could not join the room.", 17, white, true)
                    label("Check that both phones are on the same Wi-Fi or hotspot and the host has created a room.", 14, muted)
                    button("TRY AGAIN") { showJoin(); discoverRoom() }
                    button("HOME") { showHome() }
                }
            }
        }
    }

    private fun showWaiting() {
        setup("ROOM JOINED")
        label("You're in the room. Secret roles and game actions will appear when the host starts.", 17, white)
        waitingStatusText = label(statusText, 13, muted)
        button("LEAVE ROOM") { closeServer(); showHome() }
    }

    private fun publishGameState() {
        peers.forEach { peer ->
            try {
                peer.writer.println(partyGame.stateFor(peer.id, playerId).toString())
            } catch (_: Exception) { }
        }
        val ownState = partyGame.stateFor(playerId, playerId)
        runOnUiThread {
            acceptGameState(ownState)
            syncHostNightTimers()
        }
        scheduleBotAction()
    }

    private fun syncHostNightTimers() {
        if (!hostMode || partyGame.currentPhase != "NIGHT_ACTIVITY") {
            wolfDeadlineTask?.let(mainHandler::removeCallbacks)
            nightDeadlineTask?.let(mainHandler::removeCallbacks)
            wolfDeadlineTask = null
            nightDeadlineTask = null
            scheduledWolfDeadlineAt = 0L
            scheduledNightDeadlineAt = 0L
            return
        }

        val wolfDeadline = partyGame.wolfAgreementDeadline()
        if (wolfDeadline > 0L && wolfDeadline != scheduledWolfDeadlineAt) {
            wolfDeadlineTask?.let(mainHandler::removeCallbacks)
            scheduledWolfDeadlineAt = wolfDeadline
            wolfDeadlineTask = Runnable {
                if (!hostMode || partyGame.currentPhase != "NIGHT_ACTIVITY") return@Runnable
                if (wolfDeadline > System.currentTimeMillis()) {
                    scheduledWolfDeadlineAt = 0L
                    syncHostNightTimers()
                } else if (partyGame.handle(
                        playerId,
                        playerId,
                        JSONObject().put("action", "lockWolfAgreement"),
                    )
                ) {
                    publishGameState()
                } else {
                    scheduledWolfDeadlineAt = 0L
                    syncHostNightTimers()
                }
            }.also {
                mainHandler.postDelayed(
                    it,
                    (wolfDeadline - System.currentTimeMillis()).coerceAtLeast(0L) + 120L,
                )
            }
        }

        val nightDeadline = partyGame.nightDeadline()
        if (nightDeadline > 0L && nightDeadline != scheduledNightDeadlineAt) {
            nightDeadlineTask?.let(mainHandler::removeCallbacks)
            scheduledNightDeadlineAt = nightDeadline
            nightDeadlineTask = Runnable {
                if (!hostMode || partyGame.currentPhase != "NIGHT_ACTIVITY") return@Runnable
                if (nightDeadline > System.currentTimeMillis()) {
                    scheduledNightDeadlineAt = 0L
                    syncHostNightTimers()
                } else if (partyGame.handle(
                        playerId,
                        playerId,
                        JSONObject().put("action", "endNight"),
                    )
                ) {
                    publishGameState()
                } else {
                    scheduledNightDeadlineAt = 0L
                    syncHostNightTimers()
                }
            }.also {
                mainHandler.postDelayed(
                    it,
                    (nightDeadline - System.currentTimeMillis()).coerceAtLeast(0L) + 120L,
                )
            }
        }
    }

    private fun scheduleBotAction() {
        if (!isDebugBuild() || !hostMode || botIds.isEmpty() || !partyGame.isStarted) return
        synchronized(botScheduleLock) {
            if (botActionScheduled) return
            botActionScheduled = true
        }
        mainHandler.postDelayed({
            synchronized(botScheduleLock) { botActionScheduled = false }
            runNextBotAction()
        }, 550L)
    }

    private fun runNextBotAction() {
        if (!isDebugBuild() || !hostMode || !partyGame.isStarted) return
        val phase = partyGame.currentPhase
        for (botId in botIds.toList()) {
            val state = partyGame.stateFor(botId, playerId)
            val action = botActionFor(phase, botId, state) ?: continue
            if (partyGame.handle(botId, playerId, action)) {
                publishGameState()
                return
            }
        }
    }

    private fun botActionFor(phase: String, botId: String, state: JSONObject): JSONObject? {
        val role = state.optString("myRole")
        val alivePlayers = gamePlayers(state).filter { it.alive }
        val otherAlive = alivePlayers.filter { it.id != botId }
        fun action(name: String) = JSONObject().put("action", name)
        fun targetAction(name: String, targetId: String) =
            action(name).put("targetId", targetId)

        return when (phase) {
            "ROLE_REVEAL" ->
                if (!state.optBoolean("myActionDone")) action("ready") else null

            "CHIEF_ELECTION" -> {
                if (state.optBoolean("myActionDone")) return null
                val candidates = state.optJSONArray("chiefCandidates") ?: JSONArray()
                val candidate = (0 until candidates.length())
                    .mapNotNull { candidates.optJSONObject(it)?.optString("id") }
                    .randomOrNull()
                candidate?.let { targetAction("chiefVote", it) }
            }

            "CHIEF_SUCCESSION" -> {
                if (!state.optBoolean("canChooseChiefSuccessor")) return null
                val candidates = state.optJSONArray("chiefSuccessorCandidates") ?: JSONArray()
                val target = (0 until candidates.length())
                    .mapNotNull { candidates.optJSONObject(it)?.optString("id") }
                    .randomOrNull()
                target?.let { targetAction("chooseChiefSuccessor", it) }
            }

            "NIGHT_ACTIVITY" -> {
                if (!state.optBoolean("myAlive")) return null
                when (role) {
                    "WOLF" -> {
                        if (state.optBoolean("wolvesLocked")) return null
                        val targets = state.optJSONArray("wolfTargets") ?: JSONArray()
                        val validTargets = (0 until targets.length())
                            .mapNotNull { targets.optJSONObject(it)?.optString("id") }
                        if (validTargets.isEmpty()) return null
                        val proposals = state.optJSONArray("wolfProposals") ?: JSONArray()
                        val teammatePicks = (0 until proposals.length())
                            .mapNotNull { proposals.optJSONObject(it) }
                            .filter { it.optString("id") != botId && it.optString("targetId") in validTargets }
                            .groupingBy { it.optString("targetId") }
                            .eachCount()
                        val agreedCandidate = teammatePicks.maxByOrNull { it.value }?.key
                        val ownProposal = state.optString("myWolfProposalId")
                            .takeIf { it in validTargets }
                        val target = agreedCandidate ?: ownProposal ?: validTargets.randomOrNull()
                            ?: return null
                        when {
                            ownProposal != target -> targetAction("wolfPropose", target)
                            !state.optBoolean("myWolfConfirmed") -> action("wolfConfirm")
                            else -> null
                        }
                    }

                    "SEER" -> {
                        if (state.optBoolean("myActionDone")) null
                        else otherAlive.randomOrNull()?.let { targetAction("seer", it.id) }
                    }

                    "WITCH" -> {
                        if (state.optBoolean("myActionDone")) null
                        else {
                            val heal = state.optInt("witchHealCharges") > 0 &&
                                kotlin.random.Random.nextInt(100) < 45
                            val poisonTarget = if (state.optInt("witchKillCharges") > 0 &&
                                kotlin.random.Random.nextInt(100) < 35
                            ) alivePlayers.randomOrNull()?.id else null
                            action("witch")
                                .put("heal", heal)
                                .put("poisonTargetId", poisonTarget ?: "")
                        }
                    }

                    "SALVATEUR" -> {
                        if (state.optBoolean("myActionDone")) null
                        else {
                            val selfAvailable = state.optBoolean("canProtectSelf")
                            val othersAvailable = state.optBoolean("canProtectOthers")
                            val protectSelf = selfAvailable && (!othersAvailable || kotlin.random.Random.nextBoolean())
                            val target = when {
                                protectSelf -> botId
                                othersAvailable -> otherAlive.randomOrNull()?.id
                                selfAvailable -> botId
                                else -> null
                            }
                            target?.let { targetAction("protect", it) } ?: action("skipProtect")
                        }
                    }

                    else -> if (state.optBoolean("myActionDone")) null
                    else otherAlive.randomOrNull()?.let { targetAction("trustVote", it.id) }
                }
            }

            "HUNTER_ACTION" -> {
                if (!state.optBoolean("mayChooseHunterTarget")) return null
                otherAlive.randomOrNull()?.let { targetAction("hunterShot", it.id) }
            }

            "DISCUSSION" ->
                if (state.optBoolean("canSetOrder")) action("beginOrder") else null

            "ORDER_SETUP" -> {
                if (!state.optBoolean("canSetOrder")) return null
                val ids = JSONArray().apply { alivePlayers.shuffled().forEach { put(it.id) } }
                action("setOrder").put("ids", ids)
            }

            "VILLAGE_VOTE" -> {
                if (state.optString("currentVoterId") != botId || state.optBoolean("myActionDone")) return null
                otherAlive.randomOrNull()?.let { targetAction("villageVote", it.id) }
            }

            else -> null
        }
    }

    private fun acceptGameState(state: JSONObject) {
        val phase = state.optString("phase")
        val previousPhase = lastLocalPhase
        val phaseChanged = phase != previousPhase
        if (phaseChanged && phase == "ROLE_REVEAL") lastVoteAnnouncementSequence = -1
        if (phaseChanged) {
            if (phase != "NIGHT_ACTIVITY") {
                mainHandler.removeCallbacks(nightCountdownRunnable)
                nightCountdownLabel = null
                wolfCountdownLabel = null
                seerRevealRunnable?.let(mainHandler::removeCallbacks)
                seerRevealRunnable = null
                seerRevealTargetId = ""
                seerRevealRoleVisible = false
                seerRevealDismissedTargetId = ""
                seerAnnouncementTargetId = ""
            }
            if (phase == "ROLE_REVEAL") roleCardVisible = false
            if (phase == "ORDER_SETUP") orderDraft.clear()
            if (phase == "NIGHT_ACTIVITY") {
                witchHealDraft = false
                witchPoisonDraftId = null
            }
            lastLocalPhase = phase
        }
        localGameState = state
        if (phase == "NIGHT_ACTIVITY" && state.optString("myRole") == "WOLF" && state.optBoolean("myAlive")) {
            val proposals = state.optJSONArray("wolfProposals") ?: JSONArray()
            val ownTarget = state.optString("myWolfProposalId")
            val ownConfirmed = state.optBoolean("myWolfConfirmed")
            val teammate = (0 until proposals.length()).mapNotNull { proposals.optJSONObject(it) }
                .firstOrNull { it.optString("id") != playerId && it.optBoolean("confirmed") && it.optString("targetId").isNotBlank() }
            if (teammate != null && !(ownConfirmed && ownTarget == teammate.optString("targetId"))) {
                val targetId = teammate.optString("targetId")
                val promptKey = "${state.optInt("day")}:${teammate.optString("id")}:$targetId"
                if (promptKey != lastWolfApprovalPromptKey) {
                    lastWolfApprovalPromptKey = promptKey
                    val targetName = teammate.optString("targetName", "that player")
                    mainHandler.post {
                        if (!isFinishing && localGameState?.optString("phase") == "NIGHT_ACTIVITY") {
                            android.app.AlertDialog.Builder(this)
                                .setTitle("Your Wolf teammate has a target")
                                .setMessage("Your friend wants to kill $targetName. Do you agree?")
                                .setNegativeButton("NO, CHANGE") { _, _ -> }
                                .setPositiveButton("YES, AGREE") { _, _ ->
                                    sendGameAction("wolfPropose", JSONObject().put("targetId", targetId))
                                    mainHandler.postDelayed({ sendGameAction("wolfConfirm") }, 220L)
                                }
                                .show()
                        }
                    }
                }
            }
        }
        if (phase == "NIGHT_ACTIVITY") {
            val day = state.optInt("day")
            if (day != nightPuzzleDay) {
                nightPuzzleDay = day
                nightPuzzleSymbols = (listOf("☾", "🐺", "🔮", "🧪", "🌙", "🗝️", "🕯️", "⭐")
                    .flatMap { listOf(it, it) })
                    .shuffled(kotlin.random.Random(day * 7_919 + 13))
                nightPuzzleMatched.clear()
                nightPuzzleFirstPick = null
                nightPuzzleTileViews.clear()
                nightPuzzleResetRunnable?.let(mainHandler::removeCallbacks)
                nightPuzzleResetRunnable = null
                nightPuzzleFeedback = ""
                nightPuzzleSolved = false
                seerRevealRunnable?.let(mainHandler::removeCallbacks)
                seerRevealRunnable = null
                seerRevealTargetId = ""
                seerRevealRoleVisible = false
                seerRevealDismissedTargetId = ""
                seerAnnouncementTargetId = ""
            }
            nightCountdownLocalDeadline = android.os.SystemClock.elapsedRealtime() +
                state.optLong("nightRemainingMs").coerceAtLeast(0L)
            wolfCountdownLocalDeadline = android.os.SystemClock.elapsedRealtime() +
                state.optLong("wolfAgreementRemainingMs").coerceAtLeast(0L)
        } else {
            mainHandler.removeCallbacks(nightCountdownRunnable)
            nightCountdownLabel = null
            wolfCountdownLabel = null
        }
        // Network snapshots are frequent; don't rebuild the whole view tree for identical state.
        val snapshot = state.toString()
        if (snapshot != lastRenderedGameState) {
            lastRenderedGameState = snapshot
            renderGameScreen()
        }
        val voteSequence = state.optInt("voteAnnouncementSequence", 0)
        if (lastVoteAnnouncementSequence < 0) {
            lastVoteAnnouncementSequence = voteSequence
        } else if (voteSequence > lastVoteAnnouncementSequence) {
            lastVoteAnnouncementSequence = voteSequence
            val vote = state.optJSONObject("latestVoteAnnouncement")
            val voterId = vote?.optString("voterId").orEmpty()
            val voterName = vote?.optString("voterName").orEmpty()
            val targetName = vote?.optString("targetName").orEmpty()
            if (voterId.isNotBlank() && voterId != playerId && voterName.isNotBlank() && targetName.isNotBlank()) {
                val isChiefVote = vote?.optString("voteType") == "CHIEF"
                mainHandler.postDelayed({
                    if (!isFinishing && !isDestroyed) showVoteLine(voterName, targetName, isChiefVote)
                }, 80L)
            }
        }
        if (phaseChanged && previousPhase == "CHIEF_ELECTION" && phase == "CHIEF_RESULT") {
            val chiefName = state.optString("chiefName").ifBlank { "The Village Chief" }
            mainHandler.postDelayed({
                if (!isFinishing && !isDestroyed) {
                    showGameAnnouncement(
                        title = "YOUR VILLAGE CHIEF",
                        message = "$chiefName is your Village Chief.",
                        detail = "Their daytime vote counts twice, and they choose the voting order.",
                        symbol = "♛",
                        highlightColor = gold,
                    )
                }
            }, 180L)
        }
        if (phaseChanged && previousPhase == "NIGHT_ACTIVITY") {
            val outcomes = nightOutcomeDetails(state)
            if (outcomes.isNotEmpty()) {
                val hasDeaths = state.optJSONArray("nightDeathAnnouncements")?.length()?.let { it > 0 } == true
                mainHandler.postDelayed({
                    if (!isFinishing && !isDestroyed) {
                        showGameAnnouncement(
                            title = "DAWN REPORT",
                            message = "The village has woken. Here are the night outcomes:",
                            symbol = if (hasDeaths) "⚔" else "🛡",
                            highlightColor = if (hasDeaths) Color.rgb(255, 112, 121) else Color.rgb(120, 225, 188),
                            details = outcomes,
                            playDeathSound = hasDeaths,
                        )
                    }
                }, 180L)
            }
        }
    }

    private fun sendGameAction(action: String, details: JSONObject = JSONObject()) {
        val message = JSONObject().put("type", "action").put("action", action)
        val keys = details.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            message.put(key, details.opt(key))
        }
        if (hostMode) {
            if (partyGame.handle(playerId, playerId, message)) publishGameState()
        } else {
            val writer = clientWriter
            if (writer == null) {
                Toast.makeText(this, "Not connected to a room.", Toast.LENGTH_SHORT).show()
            } else {
                writer.println(message.toString())
            }
        }
    }

    private fun gamePlayers(state: JSONObject): List<GamePlayer> {
        val array = state.optJSONArray("players") ?: return emptyList()
        return (0 until array.length()).mapNotNull { index ->
            val item = array.optJSONObject(index) ?: return@mapNotNull null
            GamePlayer(item.optString("id"), item.optString("name"), item.optBoolean("alive"))
        }
    }

    private fun nameFrom(state: JSONObject, id: String): String =
        gamePlayers(state).firstOrNull { it.id == id }?.name ?: "Player"

    private fun phaseTitle(phase: String): String = when (phase) {
        "ROLE_REVEAL" -> "SECRET ROLE"
        "CHIEF_ELECTION" -> "VILLAGE CHIEF"
        "CHIEF_RESULT" -> "CHIEF ELECTED"
        "CHIEF_SUCCESSION" -> "VILLAGE CHIEF"
        "NIGHT_ACTIVITY" -> "THE VILLAGE SLEEPS"
        "NIGHT_WOLF" -> "THE VILLAGE SLEEPS"
        "NIGHT_SEER" -> "SEER'S TURN"
        "NIGHT_WITCH" -> "WITCH'S TURN"
        "NIGHT_PROTECTOR" -> "SALVATEUR'S TURN"
        "HUNTER_ACTION" -> "FINAL SHOT"
        "MORNING" -> "THE VILLAGE WAKES"
        "DISCUSSION" -> "DISCUSSION"
        "ORDER_SETUP" -> "VOTING ORDER"
        "VILLAGE_VOTE" -> "VILLAGE VOTE"
        "DAY_RESULT" -> "VOTE RESULT"
        "GAME_OVER" -> "GAME OVER"
        else -> "WOLVES & VILLAGERS"
    }

    private fun roleDisplay(role: String): String = when (role) {
        "WOLF" -> "🐺 WOLF"
        "VILLAGER" -> "🧑 VILLAGER"
        "SEER" -> "🔮 SEER"
        "WITCH" -> "🧙 WITCH"
        "SALVATEUR" -> "🛡️ SALVATEUR"
        "CHASSEUR" -> "🏹 CHASSEUR"
        else -> role
    }

    private fun showVoteLine(voterName: String, targetName: String, chiefVote: Boolean) {
        val line = TextView(this).apply {
            text = "$voterName > $targetName"
            textSize = 19f
            gravity = Gravity.CENTER
            setTextColor(white)
            setPadding(dp(22), dp(16), dp(22), dp(16))
            if (!chiefVote) {
                val text = android.text.SpannableString("$voterName > $targetName")
                val split = voterName.length
                text.setSpan(android.text.style.ForegroundColorSpan(Color.rgb(95, 210, 130)), 0, split, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                val targetStart = split + 3
                if (targetStart < text.length) text.setSpan(android.text.style.ForegroundColorSpan(Color.rgb(235, 95, 105)), targetStart, text.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                this.text = text
            }
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                cornerRadius = dp(18).toFloat()
                setColor(panel)
                setStroke(dp(1), Color.rgb(65, 78, 111))
            }
        }
        val dialog = android.app.AlertDialog.Builder(this).setView(line).create()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        line.setOnClickListener { dialog.dismiss() }
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        mainHandler.postDelayed({ if (dialog.isShowing) dialog.dismiss() }, 1600L)
    }

    private fun renderGameScreen() {
        val state = localGameState ?: return
        val phase = state.optString("phase")
        val living = gamePlayers(state).filter { it.alive }
        val myRole = state.optString("myRole")
        setup(phaseTitle(phase))
        if (phase == "ROLE_REVEAL") renderPrivateRole(state)

        when (phase) {
            "ROLE_REVEAL" -> {
                label("Your role is private. Show your phone only to yourself.", 15, muted)
                label("${state.optInt("readyCount")} of ${state.optInt("readyTotal")} players are ready.", 16, white, true)
                if (state.optBoolean("myActionDone")) {
                    label("You're ready. Waiting for everyone else…", 14, muted)
                } else {
                    button("I'M READY") { sendGameAction("ready") }
                }
            }

            "CHIEF_ELECTION" -> {
                label("Two players were chosen at random. Everyone votes for one Village Chief.", 15, muted)
                renderVoteCounts(state)
                if (state.optBoolean("myActionDone")) {
                    label("Your vote is in. Watch the public vote-by-vote results.", 14, white)
                } else {
                    val candidates = state.optJSONArray("chiefCandidates") ?: JSONArray()
                    val options = (0 until candidates.length()).mapNotNull { index ->
                        candidates.optJSONObject(index)?.let { candidate ->
                            val id = candidate.optString("id")
                            if (id != playerId) ChoiceOption(id, "VOTE FOR ${candidate.optString("name")}") else null
                        }
                    }
                    choiceBubbles(options) { candidate ->
                        sendGameAction("chiefVote", JSONObject().put("targetId", candidate.id))
                    }
                }
            }

            "CHIEF_RESULT" -> {
                label("${state.optString("chiefName")} is your Village Chief.", 20, white, true)
                label("The Chief's vote counts twice and they choose the order of daytime votes.", 14, muted)
                if (state.optBoolean("canStartNight")) button("START THE FIRST NIGHT") { sendGameAction("beginNight") }
                else label("Waiting for the host to begin the first night…", 14, muted)
            }

            "NIGHT_ACTIVITY" -> renderNightActivity(state, living, myRole)
            "CHIEF_SUCCESSION" -> renderChiefSuccession(state, living)
            "NIGHT_WOLF" -> renderWolfNight(state, living, myRole)
            "NIGHT_SEER" -> renderSeerTurn(state, living, myRole)
            "NIGHT_WITCH" -> renderWitchTurn(state, living, myRole)
            "NIGHT_PROTECTOR" -> renderProtectorTurn(state, living, myRole)
            "HUNTER_ACTION" -> renderHunterTurn(state, living)

            "MORNING" -> {
                label(state.optString("morningSummary", "The village wakes."), 18, gold, true)
                label("Put your phones down and discuss what happened.", 15, white, true)
                renderLivingPlayers(living)
                if (state.optBoolean("canStartDiscussion")) button("START DISCUSSION") { sendGameAction("startDiscussion") }
                else label("Waiting for the host to open discussion…", 14, muted)
            }

            "DISCUSSION" -> {
                label("Talk together and decide what you believe. No roles are revealed.", 15, muted)
                renderLivingPlayers(living)
                if (state.optBoolean("canSetOrder")) {
                    button("CHOOSE THE VOTING ORDER") { sendGameAction("beginOrder") }
                } else {
                    val chooser = if (state.optBoolean("chiefAlive")) state.optString("chiefName") else "The host"
                    label("$chooser is choosing the voting order.", 14, muted)
                }
            }

            "ORDER_SETUP" -> renderVotingOrder(state, living)
            "VILLAGE_VOTE" -> renderVillageVote(state, living)

            "DAY_RESULT" -> {
                label(state.optString("lastVoteResult", "The village vote is complete."), 19, white, true)
                renderVoteCounts(state)
                renderLivingPlayers(living)
                if (state.optBoolean("canStartNextNight")) button("THE VILLAGE GOES TO SLEEP") { sendGameAction("startNextNight") }
                else label("Waiting for the host to start the next night…", 14, muted)
            }

            "GAME_OVER" -> {
                label(state.optString("winner", "The game is over."), 25, gold, true)
                label("Roles remain private, even after the game.", 14, muted)
                renderLivingPlayers(living)
                button("LEAVE ROOM") { closeServer(); roomStarted = false; showHome() }
            }
        }
        // Public event history is intentionally hidden; phase reports carry only the current outcome.
    }

    private fun renderChiefSuccession(state: JSONObject, living: List<GamePlayer>) {
        if (!state.optBoolean("canChooseChiefSuccessor")) {
            label("The former Village Chief is choosing a successor.", 15, muted)
            return
        }

        label("You were the Village Chief. Choose a living player to succeed you.", 16, white, true)
        val candidates = state.optJSONArray("chiefSuccessorCandidates") ?: JSONArray()
        val candidateIds = (0 until candidates.length())
            .mapNotNull { candidates.optJSONObject(it)?.optString("id") }
            .toSet()
        val eligiblePlayers = living.filter { it.id in candidateIds }

        if (eligiblePlayers.isEmpty()) {
            label("No living player is available to become Village Chief.", 14, muted)
            return
        }

        eligiblePlayers.forEach { candidate ->
            button("CHOOSE ${candidate.name} AS VILLAGE CHIEF") {
                sendGameAction(
                    "chooseChiefSuccessor",
                    JSONObject().put("targetId", candidate.id),
                )
            }
        }
    }

    private fun renderPrivateRole(state: JSONObject) {
        val role = state.optString("myRole")
        if (role.isBlank()) return
        space(8)
        if (!roleCardVisible) {
            val cardBack = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(22), dp(18), dp(22))
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    cornerRadius = dp(20).toFloat()
                    setColor(Color.rgb(27, 10, 23))
                    setStroke(dp(2), accent)
                }
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    roleCardVisible = true
                    renderGameScreen()
                    playUiClickSound()
                }
            }
            TextView(this).apply {
                text = "✦  RED WOLF  ✦"
                textSize = 15f; setTextColor(gold); gravity = Gravity.CENTER
                setTypeface(null, android.graphics.Typeface.BOLD); letterSpacing = 0.12f
            }.also { cardBack.addView(it) }
            TextView(this).apply {
                text = "🐺"
                textSize = 48f; gravity = Gravity.CENTER; setTextColor(accent)
                setPadding(0, dp(12), 0, dp(12))
            }.also { cardBack.addView(it) }
            TextView(this).apply {
                text = "TAP TO REVEAL YOUR ROLE"
                textSize = 13f; setTextColor(white); gravity = Gravity.CENTER
                setTypeface(null, android.graphics.Typeface.BOLD); letterSpacing = 0.06f
            }.also { cardBack.addView(it) }
            root.addView(cardBack, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170)).apply { bottomMargin = dp(10) })
            return
        }
        val roleCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(20), dp(18), dp(18))
            background = ornateSurface(Color.rgb(24, 13, 28), if (role == "WOLF") accent else gold)
            alpha = 0f
        }
        TextView(this).apply {
            text = if (role == "WOLF") "🐺" else when (role) { "WITCH" -> "⚗"; "SEER" -> "◉"; "SALVATEUR" -> "✧"; "CHASSEUR" -> "♜"; else -> "☾" }
            textSize = 42f; gravity = Gravity.CENTER; setTextColor(if (role == "WOLF") accent else gold)
        }.also { roleCard.addView(it) }
        TextView(this).apply {
            text = "YOUR ROLE\n${roleDisplay(role)}"
            textSize = 22f; setTextColor(white); gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, dp(8), 0, dp(8))
        }.also { roleCard.addView(it) }
        root.addView(roleCard, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) })
        roleCard.animate().alpha(1f).setDuration(220L).start()
        val description = when (role) {
            "WOLF" -> "Your Wolf pack can see the other Wolves. Keep your identity secret from the village."
            "VILLAGER" -> "Talk with the village, read the votes, and find the Wolves."
            "SEER" -> "Each night, privately inspect one living player's role."
            "WITCH" -> "Choose one potion action per night: heal OR poison, never both."
            "SALVATEUR" -> "Protect yourself once and another player once during the game."
            "CHASSEUR" -> "If you are eliminated, choose one living player to take with you."
            else -> "Keep your role secret."
        }
        label(description, 14, Color.WHITE)
        if (role == "WOLF") {
            val friends = state.optJSONArray("wolfFriends") ?: JSONArray()
            val packNames = (0 until friends.length()).map { friends.optString(it) }
            val packText = if (packNames.isEmpty()) "You are the only Wolf." else "Your Wolf friends: ${packNames.joinToString(" and ")}"
            label(packText, 16, Color.WHITE, true)
        }
        button("HIDE MY ROLE") {
            roleCardVisible = false
            renderGameScreen()
        }
    }

    private fun choiceBubbles(
        options: List<ChoiceOption>,
        selectedId: String? = null,
        onChoose: (ChoiceOption) -> Unit,
    ) {
        if (options.isEmpty()) return
        val grid = android.widget.GridLayout(this).apply {
            columnCount = 2
            alignmentMode = android.widget.GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
        }
        options.forEachIndexed { index, option ->
            val selected = option.id == selectedId
            val tile = Button(this).apply {
                text = UiText.localize(option.label, isArabicUi())
                textSize = 15f
                isAllCaps = false
                gravity = Gravity.CENTER
                textAlignment = View.TEXT_ALIGNMENT_CENTER
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(if (selected) gold else white)
                minHeight = dp(54)
                setPadding(dp(7), dp(5), dp(7), dp(5))
                maxLines = 2
                textSize = 13f
                stateListAnimator = null
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    cornerRadius = dp(22).toFloat()
                    setColor(if (selected) Color.rgb(48, 42, 69) else Color.rgb(20, 27, 49))
                    setStroke(dp(if (selected) 2 else 1), if (selected) gold else Color.rgb(80, 101, 145))
                }
                setOnClickListener {
                    val motionScale = android.provider.Settings.Global.getFloat(
                        contentResolver,
                        android.provider.Settings.Global.ANIMATOR_DURATION_SCALE,
                        1f,
                    )
                    if (motionScale > 0f) {
                        animate().scaleX(0.95f).scaleY(0.95f).setDuration(85L).withEndAction {
                            animate().scaleX(1f).scaleY(1f).setDuration(130L)
                                .withEndAction { onChoose(option) }.start()
                        }.start()
                    } else {
                        onChoose(option)
                    }
                }
            }
            val params = android.widget.GridLayout.LayoutParams(
                android.widget.GridLayout.spec(index / 2, 1f),
                android.widget.GridLayout.spec(index % 2, 1f),
            ).apply {
                width = 0
                height = dp(104)
                setMargins(dp(5), dp(5), dp(5), dp(5))
            }
            grid.addView(tile, params)
        }
        root.addView(grid, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
        ).apply { bottomMargin = dp(8) })
    }

    private fun renderNightActivity(state: JSONObject, living: List<GamePlayer>, role: String) {
        if (state.optBoolean("myAlive") && role == "SEER" && !state.optBoolean("myActionDone")) {
            renderSeerTurn(state, living, role)
        } else if (state.optBoolean("myAlive") && !state.optBoolean("myActionDone")) {
            when (role) {
                "WOLF" -> renderWolfCoordination(state)
                "SEER" -> renderSeerTurn(state, living, role)
                "WITCH" -> renderWitchTurn(state, living, role)
                "SALVATEUR" -> renderProtectorTurn(state, living, role)
                else -> {
                    val options = living.filter { it.id != playerId }
                        .map { target -> ChoiceOption(target.id, target.name) }
                    choiceBubbles(options) { target ->
                        sendGameAction("trustVote", JSONObject().put("targetId", target.id))
                    }
                }
            }
        }
        // After submitting a role action, only the puzzle remains visible.
        renderNightPuzzle(state, role)
    }

    private fun renderNightPuzzle(state: JSONObject, role: String) {
        if (state.optString("phase") != "NIGHT_ACTIVITY") return
        if (!state.optBoolean("myAlive")) {
            label("☾", 34, gold, true)
            return
        }
        label("MATCH THE PAIRS", 17, gold, true)
        if (nightPuzzleSolved) {
            label("✓", 28, gold, true)
            return
        }
        if (nightPuzzleSymbols.size != 16) {
            nightPuzzleSymbols = listOf("☾", "🐺", "🔮", "🧪", "🌙", "🗝️", "🕯️", "⭐")
                .flatMap { listOf(it, it) }.shuffled()
        }
        nightPuzzleTileViews.clear()
        val tileSizeDp = ((resources.configuration.screenWidthDp - 48 - 4 * 8) / 4).coerceIn(48, 70)
        val grid = android.widget.GridLayout(this).apply {
            columnCount = 4
            rowCount = 4
            alignmentMode = android.widget.GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
        }
        for (index in 0 until 16) {
            val tile = Button(this).apply {
                text = if (index in nightPuzzleMatched || index == nightPuzzleFirstPick) nightPuzzleSymbols[index] else "✦"
                textSize = 22f
                isAllCaps = false
                gravity = Gravity.CENTER
                setTextColor(if (index in nightPuzzleMatched) gold else white)
                stateListAnimator = null
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    cornerRadius = dp(14).toFloat()
                    setColor(if (index in nightPuzzleMatched) Color.rgb(53, 65, 80) else panel)
                    setStroke(dp(1), if (index in nightPuzzleMatched) gold else Color.rgb(65, 78, 111))
                }
                setOnClickListener {
                    if (nightPuzzleSolved || index in nightPuzzleMatched || index == nightPuzzleFirstPick) return@setOnClickListener
                    if (nightPuzzleFirstPick == null) {
                        nightPuzzleFirstPick = index
                        showPuzzleTile(index, true)
                    } else {
                        val first = nightPuzzleFirstPick!!
                        showPuzzleTile(index, true)
                        if (nightPuzzleSymbols[first] == nightPuzzleSymbols[index]) {
                            nightPuzzleMatched.add(first)
                            nightPuzzleMatched.add(index)
                            nightPuzzleFirstPick = null
                            showPuzzleTile(first, true)
                            showPuzzleTile(index, true)
                            if (nightPuzzleMatched.size == 16) {
                                nightPuzzleSolved = true
                                nightPuzzleFeedback = ""
                                sendGameAction("puzzleDone")
                                reveal(grid, 0L, true)
                            }
                        } else {
                            nightPuzzleFirstPick = null
                            nightPuzzleResetRunnable?.let(mainHandler::removeCallbacks)
                            nightPuzzleResetRunnable = Runnable {
                                showPuzzleTile(first, false)
                                showPuzzleTile(index, false)
                                nightPuzzleResetRunnable = null
                            }.also { mainHandler.postDelayed(it, 650L) }
                        }
                    }
                }
            }
            nightPuzzleTileViews.add(tile)
            grid.addView(tile, android.widget.GridLayout.LayoutParams(
                android.widget.GridLayout.spec(index / 4), android.widget.GridLayout.spec(index % 4)
            ).apply {
                width = dp(tileSizeDp)
                height = dp(tileSizeDp)
                setMargins(dp(3), dp(3), dp(3), dp(3))
            })
        }
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        })
    }

    private fun showPuzzleTile(index: Int, faceUp: Boolean) {
        val tile = nightPuzzleTileViews.getOrNull(index) ?: return
        tile.text = if (faceUp || index in nightPuzzleMatched) nightPuzzleSymbols.getOrNull(index) ?: "✦" else "✦"
        tile.setTextColor(if (index in nightPuzzleMatched) gold else white)
        tile.background = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(14).toFloat()
            setColor(if (index in nightPuzzleMatched) Color.rgb(53, 65, 80) else if (faceUp) Color.rgb(55, 43, 75) else panel)
            setStroke(dp(1), if (index in nightPuzzleMatched) gold else Color.rgb(65, 78, 111))
        }
        tile.animate().cancel()
        tile.scaleX = 0.86f
        tile.scaleY = 0.86f
        tile.animate().scaleX(1f).scaleY(1f).setDuration(120L).start()
    }

    private fun renderWolfCoordination(state: JSONObject) {
        label("🐺 WOLF PACK", 16, gold, true)
        val locked = state.optBoolean("wolvesLocked")
        val proposalId = state.optString("myWolfProposalId")
        val confirmed = state.optBoolean("myWolfConfirmed")
        if (locked) {
            wolfCountdownLabel = null
            label("Target locked", 14, gold, true)
        } else {
            wolfCountdownLabel = null
            val targets = state.optJSONArray("wolfTargets") ?: JSONArray()
            val options = (0 until targets.length()).mapNotNull { index ->
                targets.optJSONObject(index)?.let { target ->
                    ChoiceOption(target.optString("id"), target.optString("name"))
                }
            }
            choiceBubbles(options, selectedId = proposalId) { target ->
                sendGameAction("wolfPropose", JSONObject().put("targetId", target.id))
            }
            if (proposalId.isNotBlank()) {
                if (confirmed) {
                    label("Your proposal is confirmed. Tap another player above to change it.", 14, gold)
                } else {
                    button("CONFIRM TARGET") {
                        val targetName = state.optJSONArray("wolfTargets")?.let { arr -> (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.firstOrNull { it.optString("id") == proposalId }?.optString("name") } ?: "this player"
                        showCompactConfirmation("SURE?", "Target $targetName?", "YES", "NO") {
                            sendGameAction("wolfConfirm")
                        }
                    }
                }
            } else {
                label("Choose a target, then confirm your choice.", 14, muted)
            }
        }

        val proposals = state.optJSONArray("wolfProposals") ?: JSONArray()
        if (proposals.length() > 0) {
            label("Your pack's private proposals", 14, white, true)
            for (i in 0 until proposals.length()) {
                val row = proposals.optJSONObject(i) ?: continue
                val name = row.optString("name")
                val target = row.optString("targetName").ifBlank { "No proposal yet" }
                val status = if (row.optBoolean("confirmed")) "✓ Confirmed" else "Waiting for confirmation"
                label("$name → $target · $status", 13, muted)
            }
        }
        label("The pack must agree on the same target.", 12, muted)
    }

    private fun renderWolfNight(state: JSONObject, living: List<GamePlayer>, role: String) {
        if (!state.optBoolean("myAlive")) {
            label("You are out of the game. Watch quietly while the village sleeps.", 16, white)
        } else if (role == "WOLF") {
            renderWolfCoordination(state)
        } else {
            if (state.optBoolean("myActionDone")) {
                label("Your private trust choice is recorded. It does not affect the game.", 15, muted)
            } else {
                label("Choose who you trust. This private choice has no effect on the game.", 15, white)
                val options = living.filter { it.id != playerId }
                    .map { target -> ChoiceOption(target.id, "I TRUST ${target.name}") }
                choiceBubbles(options) { target ->
                    sendGameAction("trustVote", JSONObject().put("targetId", target.id))
                }
            }
        }
    }


    private fun renderSeerTurn(state: JSONObject, living: List<GamePlayer>, role: String) {
        if (role != "SEER" || !state.optBoolean("myAlive")) {
            label("The Seer is choosing a player privately.", 15, muted)
            return
        }
        val targetId = state.optString("seerResultTargetId")
        val targetRole = state.optString("seerResultRole")
        if (targetId.isNotBlank() && targetRole.isNotBlank()) {
            if (seerRevealTargetId != targetId) {
                seerRevealRunnable?.let(mainHandler::removeCallbacks)
                seerRevealTargetId = targetId
                seerRevealRoleVisible = false
                seerRevealDismissedTargetId = ""
                seerAnnouncementTargetId = ""
                val revealTarget = targetId
                seerRevealRunnable = Runnable {
                    val current = localGameState
                    if (current?.optString("phase") == "NIGHT_ACTIVITY" &&
                        current.optString("seerResultTargetId") == revealTarget &&
                        seerRevealTargetId == revealTarget
                    ) {
                        seerRevealRoleVisible = true
                        renderGameScreen()
                    }
                }.also { mainHandler.postDelayed(it, 450L) }
            }
            if (seerRevealDismissedTargetId == targetId) {
                label("Investigation complete. Your result was private to you.", 15, muted, true)
                return
            }
            label("YOUR PRIVATE VISION", 15, gold, true)
            if (seerRevealRoleVisible) {
                label("Your result is ready in your private popup.", 15, muted)
                if (seerAnnouncementTargetId != targetId) {
                    seerAnnouncementTargetId = targetId
                    showGameAnnouncement(
                        title = "SEER SAW",
                        message = roleDisplay(targetRole),
                        detail = "This result is private to you.",
                        symbol = "🔮",
                        highlightColor = lavender,
                        onDismiss = {
                            seerRevealDismissedTargetId = targetId
                            renderGameScreen()
                        },
                    )
                }
            } else {
                label("Reading your vision…", 14, muted)
            }
            return
        }
        if (state.optBoolean("myActionDone")) {
            label("Your investigation is recorded. Stay quiet until morning.", 14, muted)
            return
        }
        label("Choose one living player to reveal their exact role to you only.", 15, white)
        val options = living.filter { it.id != playerId }
            .map { target -> ChoiceOption(target.id, "SEE ${target.name}") }
        choiceBubbles(options) { target ->
            sendGameAction("seer", JSONObject().put("targetId", target.id))
        }
    }

    private fun renderWitchTurn(state: JSONObject, living: List<GamePlayer>, role: String) {
        if (role != "WITCH" || !state.optBoolean("myAlive")) {
            label("The Witch is choosing privately.", 15, muted)
            return
        }
        if (state.optBoolean("myActionDone")) {
            label("Your potion choice is locked in. The puzzle remains on screen.", 15, white)
            return
        }
        val heals = state.optInt("witchHealCharges")
        val kills = state.optInt("witchKillCharges")
        label("Choose one potion. You cannot see the Wolves' target.", 15, white, true)
        label("Heal: $heals  •  Poison: $kills", 14, muted)
        if (heals > 0) {
            themedActionButton("✦  HEAL SOMEONE  ·  $heals", Color.rgb(70, 218, 156)) {
                showCompactConfirmation("SURE?", "Use your healing potion?", "YES", "NO") {
                    sendGameAction("witch", JSONObject().put("heal", true).put("poisonTargetId", ""))
                }
            }
        }
        if (kills > 0) {
            themedActionButton("☠  POISON A PLAYER  ·  $kills", Color.rgb(190, 105, 255)) {
                val candidates = living.filter { it.id != playerId }
                val names = candidates.map { it.name }.toTypedArray()
                android.app.AlertDialog.Builder(this)
                    .setTitle("Choose whom to poison")
                    .setItems(names) { _, which ->
                        val target = candidates.getOrNull(which) ?: return@setItems
                        showCompactConfirmation("SURE?", "Poison ${target.name}?", "YES", "NO") {
                            sendGameAction("witch", JSONObject().put("heal", false).put("poisonTargetId", target.id))
                        }
                    }
                    .setNegativeButton("CANCEL", null)
                    .show()
            }
        }
        themedActionButton("SAVE NO POTION", muted) {
            android.app.AlertDialog.Builder(this)
                .setTitle("Skip potions tonight?")
                .setNegativeButton("GO BACK", null)
                .setPositiveButton("YES, SKIP") { _, _ ->
                    sendGameAction("witch", JSONObject().put("heal", false).put("poisonTargetId", ""))
                }.show()
        }
    }

    private fun renderProtectorTurn(state: JSONObject, living: List<GamePlayer>, role: String) {
        if (role != "SALVATEUR" || !state.optBoolean("myAlive")) {
            label("The Salvateur is choosing privately.", 15, muted)
            return
        }
        if (state.optBoolean("myActionDone")) {
            label("Your protection choice is locked in.", 15, white)
            return
        }
        label("You may protect yourself once and another player once per game.", 15, white)
        if (state.optBoolean("canProtectSelf")) {
            button("PROTECT MYSELF") {
                sendGameAction("protect", JSONObject().put("targetId", playerId))
            }
        }
        if (state.optBoolean("canProtectOthers")) {
            val options = living.filter { it.id != playerId }
                .map { target -> ChoiceOption(target.id, "PROTECT ${target.name}") }
            choiceBubbles(options) { target ->
                sendGameAction("protect", JSONObject().put("targetId", target.id))
            }
        }
        button("SKIP PROTECTION TONIGHT") { sendGameAction("skipProtect") }
    }

    private fun renderHunterTurn(state: JSONObject, living: List<GamePlayer>) {
        val summary = state.optString("morningSummary")
        if (summary.isNotBlank()) label(summary, 16, white, true)
        if (state.optBoolean("mayChooseHunterTarget")) {
            label("You were eliminated. Choose one living player to take with you.", 16, white, true)
            val options = living.filter { it.id != playerId }
                .map { target -> ChoiceOption(target.id, "TAKE ${target.name} WITH YOU") }
            choiceBubbles(options) { target ->
                sendGameAction("hunterShot", JSONObject().put("targetId", target.id))
            }
        } else {
            label("A fallen player is making a final choice.", 15, muted)
        }
        if (state.optBoolean("canSkipHunter")) {
            button("SKIP THE FINAL SHOT") { sendGameAction("skipHunter") }
        }
    }

    private fun renderVotingOrder(state: JSONObject, living: List<GamePlayer>) {
        if (!state.optBoolean("canSetOrder")) {
            val chooser = if (state.optBoolean("chiefAlive")) state.optString("chiefName") else "The host"
            label("$chooser is choosing who votes first, second, and next.", 15, muted)
            return
        }
        label("Choose the complete voting order. Everyone will see each vote as it happens.", 15, white)
        if (orderDraft.isEmpty()) label("No voters added yet.", 13, muted)
        else label(orderDraft.mapIndexed { index, id -> "${index + 1}. ${nameFrom(state, id)}" }.joinToString("\n"), 15, Color.WHITE)
        val options = living.filter { it.id !in orderDraft }
            .map { candidate -> ChoiceOption(candidate.id, "ADD ${orderDraft.size + 1}: ${candidate.name}") }
        choiceBubbles(options) { candidate ->
            orderDraft.add(candidate.id)
            renderGameScreen()
        }
        if (orderDraft.isNotEmpty()) {
            button("UNDO LAST") {
                orderDraft.removeAt(orderDraft.lastIndex)
                renderGameScreen()
            }
        }
        if (orderDraft.size == living.size && living.isNotEmpty()) {
            val ids = JSONArray().apply { orderDraft.forEach { put(it) } }
            button("START THE VILLAGE VOTE") { sendGameAction("setOrder", JSONObject().put("ids", ids)) }
        }
    }

    private fun renderVillageVote(state: JSONObject, living: List<GamePlayer>) {
        val currentId = state.optString("currentVoterId")
        val currentName = nameFrom(state, currentId)
        val isMyTurn = currentId == playerId
        label(
            if (isMyTurn) "YOUR TURN TO VOTE" else "$currentName is voting now.",
            22,
            if (isMyTurn) gold else white,
            true,
        )
        val isChief = state.optString("chiefId") == playerId && state.optBoolean("myAlive")
        label(
            if (isChief) "Your Village Chief ballot counts twice."
            else "The Village Chief's ballot counts twice; totals include the extra vote.",
            14,
            muted,
        )
        renderVoteCounts(state)
        if (isMyTurn && !state.optBoolean("myActionDone")) {
            label("Choose one living player to vote out.", 15, white, true)
            val options = living.filter { it.id != playerId }
                .map { target -> ChoiceOption(target.id, "VOTE FOR ${target.name}") }
            choiceBubbles(options) { target ->
                sendGameAction("villageVote", JSONObject().put("targetId", target.id))
            }
        } else if (isMyTurn) {
            label("Your vote has been recorded.", 14, muted)
        } else {
            label("Wait for $currentName to cast their vote.", 14, muted)
        }
    }

    private fun renderVoteCounts(state: JSONObject) {
        val phase = state.optString("phase")
        val isChiefElection = phase == "CHIEF_ELECTION" || phase == "CHIEF_RESULT"
        val rows = if (isChiefElection) {
            val candidates = state.optJSONArray("chiefCandidates") ?: JSONArray()
            (0 until candidates.length()).mapNotNull { index ->
                candidates.optJSONObject(index)?.let { it.optString("id") to it.optString("name") }
            }
        } else {
            gamePlayers(state)
                .filter { phase == "DAY_RESULT" || it.alive }
                .map { it.id to it.name }
        }
        if (rows.isEmpty()) return

        val countsById = mutableMapOf<String, Int>()
        val voteCounts = state.optJSONArray("voteCounts") ?: JSONArray()
        for (index in 0 until voteCounts.length()) {
            val row = voteCounts.optJSONObject(index) ?: continue
            countsById[row.optString("id")] = row.optInt("count")
        }
        val maxVotes = rows.maxOfOrNull { countsById[it.first] ?: 0 } ?: 0
        val ballotsCast = state.optInt("ballotsCast")
        val ballotsTotal = state.optInt("ballotsTotal")
        label(if (isChiefElection) "LIVE CHIEF COUNT" else "LIVE VOTE COUNT", 13, muted, true)
        if (ballotsTotal > 0) {
            label("BALLOTS CAST: $ballotsCast OF $ballotsTotal", 14, gold, true)
            val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = ballotsTotal
                this.progress = ballotsCast.coerceIn(0, ballotsTotal)
                progressTintList = android.content.res.ColorStateList.valueOf(gold)
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(46, 57, 82))
                minHeight = dp(10)
            }
            root.addView(progress, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(10),
            ).apply { bottomMargin = dp(12) })
        }

        rows.forEach { (id, name) ->
            val count = countsById[id] ?: 0
            val leading = maxVotes > 0 && count == maxVotes
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    cornerRadius = dp(18).toFloat()
                    setColor(if (leading) Color.rgb(48, 40, 61) else Color.rgb(19, 27, 47))
                    setStroke(dp(if (leading) 2 else 1), if (leading) gold else Color.rgb(58, 74, 108))
                }
            }
            val rowHeader = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val nameView = TextView(this).apply {
                text = name
                textSize = 17f
                setTextColor(white)
                setTypeface(null, android.graphics.Typeface.BOLD)
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            }
            rowHeader.addView(nameView, LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f,
            ))
            val countView = TextView(this).apply {
                text = UiText.localize("VOTES: $count", isArabicUi())
                textSize = 14f
                setTextColor(if (leading) gold else accent)
                setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
            }
            rowHeader.addView(countView)
            card.addView(rowHeader)
            val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = maxVotes.coerceAtLeast(1)
                progress = count.coerceAtMost(max)
                progressTintList = android.content.res.ColorStateList.valueOf(if (leading) gold else accent)
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(40, 50, 73))
                minHeight = dp(8)
            }
            card.addView(bar, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(8),
            ).apply { topMargin = dp(8) })
            card.alpha = 0f
            card.translationY = dp(8).toFloat()
            root.addView(card, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { bottomMargin = dp(8) })
            val motionScale = android.provider.Settings.Global.getFloat(
                contentResolver,
                android.provider.Settings.Global.ANIMATOR_DURATION_SCALE,
                1f,
            )
            if (motionScale > 0f) {
                card.animate().alpha(1f).translationY(0f)
                    .setDuration(260L)
                    .setInterpolator(android.view.animation.DecelerateInterpolator())
                    .start()
            } else {
                card.alpha = 1f
                card.translationY = 0f
            }
        }
    }

    private fun renderLivingPlayers(living: List<GamePlayer>) {
        label("STILL IN THE VILLAGE", 13, muted, true)
        label(living.joinToString("\n") { it.name }.ifBlank { "No one remains." }, 16, white)
    }

    private fun closeServer() {
        try { server?.close() } catch (_: Exception) {}
        peers.forEach { try { it.socket.close() } catch (_: Exception) {} }
        peers.clear()
        try { clientSocket?.close() } catch (_: Exception) {}
        clientSocket = null
        clientWriter = null
        hostMode = false
    }

    override fun onDestroy() {
        discovering = false
        mainHandler.removeCallbacksAndMessages(null)
        announcementDialog?.setOnDismissListener(null)
        announcementDialog?.dismiss()
        announcementDialog = null
        pendingGameAnnouncements.clear()
        deathSoundTrack?.let { track ->
            try {
                if (track.playState == AudioTrack.PLAYSTATE_PLAYING) track.stop()
                track.release()
            } catch (_: Exception) {}
        }
        deathSoundTrack = null
        closeServer()
        super.onDestroy()
    }
}
