# Wolves & Villagers

A bilingual Android party game where friends play secret roles together over the same Wi-Fi network or hotspot.

## Run & Operate

- `pnpm android:debug` — build the installable debug APK
- APK output: `RedWolfAndroid/app/build/outputs/apk/debug/app-debug.apk`
- Open `RedWolfAndroid/` in Android Studio to run the game on an emulator or connected Android device
- `pnpm run typecheck` — full typecheck across all packages

## Stack

- Native Android application written in Kotlin
- Gradle 8.9 wrapper, Android Gradle Plugin 8.7.3, Kotlin 2.0.21
- Android SDK Platform 35; minimum supported Android version is API 26
- Java 17 or newer

## Where things live

- `RedWolfAndroid/app/src/main/java/com/example/redwolf/MainActivity.kt` — Android screens, room networking, and player interactions
- `RedWolfAndroid/app/src/main/java/com/example/redwolf/PartyGame.kt` — host-authoritative game rules and private player state
- `RedWolfAndroid/app/src/main/java/com/example/redwolf/UiText.kt` — English/Arabic text and Arabic right-to-left support
- `RedWolfAndroid/README.md` — build instructions and Wi-Fi testing notes

## Architecture decisions

- Room discovery uses local UDP broadcasts; the room host coordinates games over TCP, so a match does not require an internet service.
- Each player's state snapshot contains only their own role and permitted private clues.
- The Village Chief is elected from two randomly selected players, has a double-weighted daytime vote, and chooses the daytime voting order.

## Product

Players create or join a room on the same Wi-Fi/hotspot, configure roles, and play a host-coordinated secret-role game with private night actions, village discussion, public voting, and optional test bots. Supports English and Arabic.

## User preferences

- Keep this project as a native Android app.

## Gotchas

- UDP room discovery depends on the local Wi-Fi/hotspot allowing device-to-device broadcasts; some guest networks isolate connected phones.
- Build the APK with `pnpm android:debug`; generated Gradle and APK files are ignored by Git.

## Pointers

- See `RedWolfAndroid/README.md` for Android build and device testing details
- See the `pnpm-workspace` skill for the shared workspace services and libraries
