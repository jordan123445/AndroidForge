---
name: Night puzzle visibility
description: Product constraint for the shared night puzzle and synchronized night timer.
---

The night puzzle is a shared, non-gameplay activity. It remains visible and playable for all players, including Wolves after unanimous target confirmation and the Witch/protector after submitting actions, until the shared 45-second night deadline expires. At the deadline, the host resolves the night and broadcasts the morning state; the puzzle then disappears for everyone.

**How to apply:** Keep puzzle visibility based on the server-authoritative night phase and fixed night deadline, not on wolf consensus or local puzzle completion. Keep all role actions validated by authoritative game logic.
