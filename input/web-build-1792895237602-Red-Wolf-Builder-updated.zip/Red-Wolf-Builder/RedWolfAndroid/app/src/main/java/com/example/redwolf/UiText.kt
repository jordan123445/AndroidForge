package com.example.redwolf

internal object UiText {
    private val arabic = mapOf(
        "RED WOLF" to "الذئب الأحمر",
        "MADE BY DIGITAL" to "صُنع بواسطة DIGITAL",
        "WOLVES & VILLAGERS" to "الذئاب والقرويون",
        "THE NIGHT IS YOURS" to "الليل لك",
        "WEREWOLF • LOCAL MULTIPLAYER" to "المستذئبون • لعب محلي متعدد",
        "A secret-role party game for friends on the same Wi-Fi or hotspot." to "لعبة أدوار سرّية للأصدقاء على نفس شبكة الواي فاي أو نقطة الاتصال.",
        "YOUR NAME" to "اسمك",
        "Enter your name" to "أدخل اسمك",
        "CREATE ROOM" to "إنشاء غرفة",
        "JOIN ROOM" to "الانضمام إلى غرفة",
        "One player creates a room. Everyone else on the same Wi-Fi or hotspot can tap JOIN ROOM to connect. No internet required." to "ينشئ لاعب غرفة، وينضم الآخرون من نفس الشبكة أو نقطة الاتصال. لا يلزم اتصال بالإنترنت.",
        "ROOM LOBBY" to "غرفة اللعب",
        "Room ready. Friends on the same Wi-Fi or hotspot can join automatically." to "الغرفة جاهزة. يمكن للأصدقاء الانضمام عبر نفس الشبكة أو نقطة الاتصال.",
        "WOLF COUNT" to "عدد الذئاب",
        "2 wolves" to "ذئبان",
        "3 wolves" to "ثلاثة ذئاب",
        "4 wolves" to "أربعة ذئاب",
        "5 wolves" to "خمسة ذئاب",
        "Salvateur" to "الحامي",
        "Chwafa (Seer)" to "العرافة",
        "Witch" to "الساحرة",
        "Chasseur (Hunter)" to "الصياد",
        "WITCH POTIONS" to "جرعات الساحرة",
        "Kill charges per game" to "عدد جرعات السم في اللعبة",
        "Heal charges per game" to "عدد جرعات العلاج في اللعبة",
        "1 use" to "استخدام واحد",
        "2 uses" to "استخدامان",
        "LOCAL TEST BOTS" to "روبوتات اختبار محلية",
        "Bots are only added to this test room and play their turns automatically." to "تُضاف الروبوتات إلى غرفة الاختبار هذه فقط، وتلعب أدوارها تلقائياً.",
        "ADD TEST BOTS TO FILL THE ROOM" to "إضافة روبوتات لإكمال اللاعبين",
        "REMOVE TEST BOTS" to "إزالة روبوتات الاختبار",
        "PLAYERS" to "اللاعبون",
        "Waiting for players…" to "بانتظار اللاعبين…",
        "Roles are shuffled each game and kept secret from the lobby." to "تُخلط الأدوار في كل لعبة وتبقى سرية.",
        "START GAME" to "بدء اللعبة",
        "BACK TO HOME" to "العودة إلى الرئيسية",
        "Searching this Wi-Fi or hotspot for an open room." to "جارٍ البحث عن غرفة على الشبكة أو نقطة الاتصال.",
        "Looking for a room…" to "جارٍ البحث عن غرفة…",
        "SEARCH AGAIN" to "البحث مجدداً",
        "BACK" to "رجوع",
        "Could not join the room." to "تعذّر الانضمام إلى الغرفة.",
        "Check that both phones are on the same Wi-Fi or hotspot and the host has created a room." to "تأكد من اتصال الهاتفين بنفس الشبكة أو نقطة الاتصال ومن إنشاء المضيف للغرفة.",
        "TRY AGAIN" to "إعادة المحاولة",
        "HOME" to "الرئيسية",
        "ROOM JOINED" to "تم الانضمام إلى الغرفة",
        "You're in the room. Secret roles and game actions will appear when the host starts." to "أنت في الغرفة. ستظهر الأدوار السرية وخيارات اللعب عند بدء المضيف.",
        "LEAVE ROOM" to "مغادرة الغرفة",
        "SECRET ROLE" to "دورك السري",
        "VILLAGE CHIEF" to "عمدة القرية",
        "CHIEF ELECTED" to "تم انتخاب العمدة",
        "THE VILLAGE SLEEPS" to "القرية نائمة",
        "SEER'S TURN" to "دور العرّاف",
        "WITCH'S TURN" to "دور الساحرة",
        "SALVATEUR'S TURN" to "دور الحامي",
        "FINAL SHOT" to "الطلقة الأخيرة",
        "THE VILLAGE WAKES" to "استيقاظ القرية",
        "DISCUSSION" to "النقاش",
        "VOTING ORDER" to "ترتيب التصويت",
        "VILLAGE VOTE" to "تصويت القرية",
        "VOTE RESULT" to "نتيجة التصويت",
        "GAME OVER" to "انتهت اللعبة",
        "YOUR ROLE" to "دورك",
        "🐺 WOLF" to "🐺 ذئب",
        "🧑 VILLAGER" to "🧑 قروي",
        "🔮 SEER" to "🔮 عرّاف",
        "🧙 WITCH" to "🧙 ساحرة",
        "🛡️ SALVATEUR" to "🛡️ الحامي",
        "🏹 CHASSEUR" to "🏹 الصياد",
        "Your role is private. Show your phone only to yourself." to "دورك سرّي. اعرض الهاتف لنفسك فقط.",
        "You're ready. Waiting for everyone else…" to "أنت جاهز. بانتظار الآخرين…",
        "I'M READY" to "أنا جاهز",
        "Two players were chosen at random. Everyone votes for one Village Chief." to "تم اختيار لاعبين عشوائياً. صوّتوا لاختيار عمدة القرية.",
        "Two players were drawn at random for the Village Chief election." to "تم اختيار لاعبين عشوائياً لانتخابات عمدة القرية.",
        "The former Village Chief is choosing a successor." to "يختار عمدة القرية السابق من يخلفه.",
        "You were the Village Chief. Choose a living player to succeed you." to "كنتَ عمدة القرية. اختر لاعباً حياً ليخلفك.",
        "No living player is available to become Village Chief." to "لا يوجد لاعب حيّ متاح ليصبح عمدة القرية.",
        "Roles were dealt privately. Each player can see only their own role." to "وُزّعت الأدوار بسرية. يستطيع كل لاعب رؤية دوره فقط.",
        "The village is awake. Discuss before setting the ballot order." to "استيقظت القرية. ناقشوا قبل تحديد ترتيب التصويت.",
        "Everyone makes a private night choice." to "لكل لاعب اختيار سرّي أثناء الليل.",
        "The village vote tied. No one is eliminated." to "تعادل تصويت القرية، ولم يخرج أحد.",
        "Your vote is in. Watch the public vote-by-vote results." to "تم تسجيل صوتك. تابعوا نتيجة التصويت.",
        "The Chief's vote counts twice and they choose the order of daytime votes." to "صوت العمدة يُحسب مرتين، وهو يختار ترتيب التصويت النهاري.",
        "Their daytime vote counts twice, and they choose the voting order." to "يُحسب صوته النهاري مرتين، ويختار ترتيب التصويت.",
        "YOUR VILLAGE CHIEF" to "عمدة قريتكم",
        "The village has woken. These players were killed:" to "استيقظت القرية. قُتل اللاعبون التاليون:",
        "The village has woken. Here are the night outcomes:" to "استيقظت القرية. هذه نتائج الليل:",
        "BALLOTS CAST" to "الأصوات المُدلى بها",
        "YOUR TURN TO VOTE" to "حان دورك للتصويت",
        "LIVE CHIEF COUNT" to "العدد المباشر لأصوات انتخاب العمدة",
        "LIVE VOTE COUNT" to "العدد المباشر للأصوات",
        "THE ROLE YOU SAW" to "الدور الذي رأيته",
        "Your Village Chief ballot counts twice." to "يُحسب صوتك بصفتك عمدة القرية مرتين.",
        "The Village Chief's ballot counts twice; totals include the extra vote." to "يُحسب صوت العمدة مرتين، وتشمل المجاميع الصوت الإضافي.",
        "The shared night puzzle has closed." to "انتهى لغز الليل المشترك.",
        "QUIET NIGHT PUZZLE" to "لغز الليل الهادئ",
        "PRIVATE NIGHT PUZZLE" to "لغز ليلي خاص",
        "Keep your phone active with this private puzzle while you wait." to "ابقَ مشغولاً بهذا اللغز الخاص أثناء الانتظار.",
        "Find all five hidden moons among the squares. Incorrect squares lock when tapped." to "اعثر على الأهلة الخمسة المخفية بين المربعات. تُقفل المربعات الخاطئة بعد لمسها.",
        "SEER SAW" to "ما رآه العرّاف",
        "THE SEER SAW" to "ما رآه العرّاف",
        "WOLF" to "ذئب",
        "VILLAGER" to "قروي",
        "This result is private to you." to "هذه النتيجة خاصة بك.",
        "Your result is ready in your private popup." to "نتيجتك جاهزة في نافذتك الخاصة.",
        "CHIEF VOTE CAST" to "تصويت العمدة",
        "PUBLIC VOTE CAST" to "تصويت علني",
        "SAVED BY THE WITCH" to "أنقذته الساحرة",
        "PROTECTED BY THE SALVATEUR" to "حماه الحامي",
        "SAVED BY THE WITCH AND THE SALVATEUR" to "أنقذته الساحرة والحامي",
        "DAWN REPORT" to "تقرير الفجر",
        "KILLED BY THE WOLVES" to "قُتل على يد الذئاب",
        "KILLED BY THE WITCH" to "قُتل بسم الساحرة",
        "KILLED BY THE WOLVES AND THE WITCH" to "قُتل على يد الذئاب والساحرة",
        "START THE FIRST NIGHT" to "بدء الليلة الأولى",
        "Waiting for the host to begin the first night…" to "بانتظار المضيف لبدء الليلة الأولى…",
        "START DISCUSSION" to "بدء النقاش",
        "Waiting for the host to open discussion…" to "بانتظار المضيف لبدء النقاش…",
        "Talk together and decide what you believe. No roles are revealed." to "ناقشوا معاً وحددوا من تثقون به. لا تُكشف الأدوار.",
        "CHOOSE THE VOTING ORDER" to "اختيار ترتيب التصويت",
        "The village vote is complete." to "اكتمل تصويت القرية.",
        "THE VILLAGE GOES TO SLEEP" to "تذهب القرية للنوم",
        "Waiting for the host to start the next night…" to "بانتظار المضيف لبدء الليلة التالية…",
        "Roles remain private, even after the game." to "تبقى الأدوار سرية حتى بعد انتهاء اللعبة.",
        "REVEAL MY ROLE" to "إظهار دوري",
        "HIDE MY ROLE" to "إخفاء دوري",
        "Your Wolf pack can see the other Wolves. Keep your identity secret from the village." to "يمكن لرفاقك الذئاب رؤية بعضهم. أبقِ هويتك سرية عن القرية.",
        "Talk with the village, read the votes, and find the Wolves." to "ناقش أهل القرية، وتابع التصويت، واكتشف الذئاب.",
        "Each night, privately inspect one living player's role." to "افحص دور لاعب حيّ سراً كل ليلة.",
        "Each night, you may heal the Wolves' target or use a poison charge." to "يمكنك علاج هدف الذئاب أو استخدام جرعة سم كل ليلة.",
        "Protect yourself once and another player once during the game." to "احمِ نفسك مرة ولاعباً آخر مرة واحدة خلال اللعبة.",
        "If you are eliminated, choose one living player to take with you." to "إذا خرجت من اللعبة، اختر لاعباً حياً ليخرج معك.",
        "Keep your role secret." to "أبقِ دورك سرياً.",
        "You are the only Wolf." to "أنت الذئب الوحيد.",
        "Everyone makes a private night choice." to "لكل لاعب اختيار سرّي أثناء الليل.",
        "You are out of the game. Watch quietly while the village sleeps." to "خرجت من اللعبة. تابع بهدوء أثناء نوم القرية.",
        "Your pack vote is recorded. Wait for the other Wolves." to "تم تسجيل اقتراحك. انتظر بقية الذئاب.",
        "Choose the player your pack wants to eliminate." to "اختروا اللاعب الذي تريدون إخراجه.",
        "Your private trust choice is recorded. It does not affect the game." to "تم تسجيل اختيارك السري للثقة. لا يؤثر في اللعبة.",
        "Choose who you trust. This private choice has no effect on the game." to "اختر من تثق به. هذا الاختيار السري لا يؤثر في اللعبة.",
        "RESOLVE NIGHT CHOICES" to "حسم اختيارات الليل",
        "The Seer is choosing a player privately." to "العرّاف يختار لاعباً بسرية.",
        "Choose one living player to reveal their role to you only." to "اختر لاعباً حياً لمعرفة دوره سراً.",
        "The Witch is choosing privately." to "الساحرة تختار بسرية.",
        "Your potion choice is locked in." to "تم تثبيت اختيار الجرعة.",
        "The Wolves did not choose a target." to "لم تختر الذئاب هدفاً.",
        "Choose a poison target or skip:" to "اختر هدف السم أو تخطَّ:",
        "NO POISON" to "بلا سم",
        "SUBMIT WITCH TURN" to "تأكيد اختيار الساحرة",
        "The Salvateur is choosing privately." to "الحامي يختار بسرية.",
        "Your protection choice is locked in." to "تم تثبيت اختيار الحماية.",
        "You may protect yourself once and another player once per game." to "يمكنك حماية نفسك مرة ولاعب آخر مرة واحدة في اللعبة.",
        "PROTECT MYSELF" to "احمِ نفسي",
        "SKIP PROTECTION TONIGHT" to "تخطّي الحماية الليلة",
        "A fallen player is making a final choice." to "لاعب خرج من اللعبة يختار الآن.",
        "SKIP THE FINAL SHOT" to "تخطّي الطلقة الأخيرة",
        "Choose the complete voting order. Everyone will see each vote as it happens." to "اختر ترتيب التصويت كاملاً. سيظهر كل صوت عند تسجيله.",
        "No voters added yet." to "لم يُضف أي ناخب بعد.",
        "UNDO LAST" to "تراجع عن الأخير",
        "START THE VILLAGE VOTE" to "بدء تصويت القرية",
        "Votes appear on every phone as they are cast. The Village Chief's ballot counts twice." to "تظهر الأصوات على الهواتف بالتتابع. صوت عمدة القرية يُحسب مرتين.",
        "Choose one living player to vote out." to "اختر لاعباً حياً لإخراجه.",
        "Your vote has been recorded." to "تم تسجيل صوتك.",
        "STILL IN THE VILLAGE" to "ما زالوا في القرية",
        "No one remains." to "لم يبقَ أحد.",
        "PUBLIC GAME LOG" to "سجل اللعبة",
        "Night ends in" to "تنتهي الليلة خلال",
        "Wolf agreement closes in" to "ينتهي اتفاق الذئاب خلال",
        "Find and tap all the crescent moons. This puzzle does not affect the game." to "ابحث عن كل الأهلة واضغط عليها. هذا اللغز لا يؤثر في اللعبة.",
        "Puzzle complete. Stay quiet until morning." to "اكتمل اللغز. التزم الهدوء حتى الصباح.",
        "Not a moon. Keep looking." to "هذا ليس هلالاً. واصل البحث.",
        "Moon found. Keep looking." to "وجدت هلالاً. واصل البحث.",
        "No one was eliminated because the village vote tied." to "تعادل تصويت القرية، ولم يُخرج أحد.",
        "The village survived the night." to "نجت القرية هذه الليلة.",
        "The Wolves win!" to "فازت الذئاب!",
        "The Villagers win!" to "فاز أهل القرية!",
        "English" to "English",
        "العربية" to "العربية",
        "CONTINUE" to "متابعة",
        "Mystery night tile" to "مربع لغز الليل",
        "Everyone has a quiet night activity. It does not affect your role or the game." to "لدى الجميع نشاط هادئ أثناء الليل، ولا يؤثر في دورك أو في مجريات اللعبة.",
        "WOLF COORDINATION — PRIVATE" to "تنسيق الذئاب — سرّي",
        "Propose a living non-Wolf. Confirm only when your pack agrees. Changing your proposal clears your confirmation." to "اقترح لاعباً حياً ليس ذئباً. أكّد فقط عندما يتفق فريقك. تغيير اقتراحك يلغي تأكيدك.",
        "Wolf agreement is locked. The morning will still arrive at the shared deadline." to "تم تثبيت اتفاق الذئاب. سيبدأ الصباح في الموعد المشترك المحدد.",
        "Your proposal is confirmed. Tap another player above to change it." to "تم تأكيد اقتراحك. اضغط لاعباً آخر أعلاه لتغييره.",
        "CONFIRM THIS TARGET" to "تأكيد هذا الهدف",
        "Choose a target, then confirm your choice." to "اختر هدفاً ثم أكّد اختيارك.",
        "Your pack's private proposals" to "اقتراحات فريقك السرية",
        "No proposal yet" to "لا يوجد اقتراح بعد",
        "✓ Confirmed" to "✓ تم التأكيد",
        "Waiting for confirmation" to "بانتظار التأكيد",
        "A kill happens only if every living Wolf confirms the same target before the deadline. Otherwise, nobody is eliminated by the Wolves." to "يحدث القتل فقط إذا أكّد جميع الذئاب الأحياء الهدف نفسه قبل انتهاء الوقت. وإلا فلن تقتل الذئاب أحداً.",
        "YOUR PRIVATE VISION" to "رؤيتك السرية",
        "Reading your vision…" to "جارٍ كشف الرؤية…",
        "Choose one living player to reveal their exact role to you only." to "اختر لاعباً حياً لمعرفة دوره الحقيقي، لك وحدك.",
        "Investigation complete. Your result was private to you." to "اكتمل التحقيق. النتيجة خاصة بك وحدك.",
        "Your investigation is recorded. Stay quiet until morning." to "تم تسجيل تحقيقك. التزم الهدوء حتى الصباح.",
        "Put your phones down and discuss what happened." to "ضعوا الهواتف جانباً وتناقشوا فيما حدث.",
        "You were eliminated. Choose one living player to take with you." to "تم إخراجك من اللعبة. اختر لاعباً حياً ليخرج معك.",
    )

    fun localize(text: String, useArabic: Boolean): String {
        if (!useArabic) return text
        if ('\n' in text) {
            return text.split('\n').joinToString("\n") { line -> localize(line, true) }
        }
        if (text.startsWith("✦ ")) return "✦ ${localize(text.removePrefix("✦ "), true)}"
        Regex("""^(.+) was killed by the Wolves and the Witch\.$""").matchEntire(text)?.let {
            return "قُتل ${it.groupValues[1]} على يد الذئاب والساحرة."
        }
        Regex("""^(.+) was killed by the Wolves\.$""").matchEntire(text)?.let {
            return "قُتل ${it.groupValues[1]} على يد الذئاب."
        }
        Regex("""^(.+) was killed by the Witch's poison\.$""").matchEntire(text)?.let {
            return "قُتل ${it.groupValues[1]} بسم الساحرة."
        }
        Regex("""^Night ends in (\d+)s$""").matchEntire(text)?.let {
            return "تنتهي الليلة خلال ${it.groupValues[1]} ث"
        }
        Regex("""^Wolf agreement closes in (\d+)s$""").matchEntire(text)?.let {
            return "ينتهي اتفاق الذئاب خلال ${it.groupValues[1]} ث"
        }
        Regex("""^BALLOTS CAST: (\d+) OF (\d+)$""").matchEntire(text)?.let {
            return "الأصوات المُدلى بها: ${it.groupValues[1]} من ${it.groupValues[2]}"
        }
        Regex("""^VOTES: (\d+)$""").matchEntire(text)?.let {
            return "الأصوات: ${it.groupValues[1]}"
        }
        Regex("""^Heal charges: (\d+)\s+•\s+Poison charges: (\d+)$""").matchEntire(text)?.let {
            return "جرعات العلاج: ${it.groupValues[1]}  •  جرعات السم: ${it.groupValues[2]}"
        }
        Regex("""^(.+) is voting now\.$""").matchEntire(text)?.let {
            return "حان دور ${it.groupValues[1]} للتصويت."
        }
        Regex("""^(.+) voted for (.+) as Village Chief\.$""").matchEntire(text)?.let {
            return "${it.groupValues[1]} صوّت لـ ${it.groupValues[2]} ليكون عمدة القرية."
        }
        Regex("""^(.+) voted to eliminate (.+)\.$""").matchEntire(text)?.let {
            return "${it.groupValues[1]} صوّت لإخراج ${it.groupValues[2]}."
        }
        Regex("""^(.+) is Village Chief\. Their vote counts twice and they choose the daytime voting order\.$""").matchEntire(text)?.let {
            return "${it.groupValues[1]} هو عمدة القرية. يُحسب صوته مرتين ويختار ترتيب التصويت النهاري."
        }
        Regex("""^(.+) set the public voting order\.$""").matchEntire(text)?.let {
            return "حدّد ${it.groupValues[1]} ترتيب التصويت العلني."
        }
        Regex("""^A final shot killed (.+)\.$""").matchEntire(text)?.let {
            return "قتلت الطلقة الأخيرة ${it.groupValues[1]}."
        }
        Regex("""^(.+) → (.+) · (.+)$""").matchEntire(text)?.let {
            return "${it.groupValues[1]} ← ${localize(it.groupValues[2], true)} · ${localize(it.groupValues[3], true)}"
        }
        arabic[text]?.let { return it }
        Regex("""^(\d+) of (\d+) players are ready\.$""").matchEntire(text)?.let {
            return "الجاهزون: ${it.groupValues[1]} من ${it.groupValues[2]}"
        }
        Regex("""^(\d+) wolves$""").matchEntire(text)?.let {
            return when (it.groupValues[1]) {
                "2" -> "ذئبان"
                "3" -> "ثلاثة ذئاب"
                "4" -> "أربعة ذئاب"
                else -> "خمسة ذئاب"
            }
        }
        Regex("""^VOTE FOR (.+)$""").matchEntire(text)?.let { return "صوّت لـ ${it.groupValues[1]}" }
        Regex("""^CHOOSE (.+) AS VILLAGE CHIEF$""").matchEntire(text)?.let {
            return "اختر ${it.groupValues[1]} ليكون عمدة القرية"
        }
        Regex("""^VOTE TO ELIMINATE (.+)$""").matchEntire(text)?.let { return "صوّتوا لإخراج ${it.groupValues[1]}" }
        Regex("""^I TRUST (.+)$""").matchEntire(text)?.let { return "أثق بـ ${it.groupValues[1]}" }
        Regex("""^SEE (.+)$""").matchEntire(text)?.let { return "اكشف دور ${it.groupValues[1]}" }
        Regex("""^PROTECT (.+)$""").matchEntire(text)?.let { return "احمِ ${it.groupValues[1]}" }
        Regex("""^TAKE (.+) WITH YOU$""").matchEntire(text)?.let { return "أخرج ${it.groupValues[1]} معك" }
        Regex("""^HEAL (.+)$""").matchEntire(text)?.let { return "عالج ${it.groupValues[1]}" }
        Regex("""^POISON (.+)$""").matchEntire(text)?.let { return "سمّم ${it.groupValues[1]}" }
        Regex("""^ADD (\d+): (.+)$""").matchEntire(text)?.let { return "إضافة ${it.groupValues[1]}: ${it.groupValues[2]}" }
        Regex("""^(.+) is your Village Chief\.$""").matchEntire(text)?.let { return "${it.groupValues[1]} هو عمدة القرية." }
        Regex("""^Your vision: (.+)$""").matchEntire(text)?.let { return "رؤيتك: ${localize(it.groupValues[1], true)}" }
        Regex("""^(.+) is a (Wolf|Villager|Seer|Witch|Salvateur|Chasseur)\.$""").matchEntire(text)?.let {
            val role = mapOf(
                "Wolf" to "ذئب",
                "Villager" to "قروي",
                "Seer" to "عرّاف",
                "Witch" to "ساحرة",
                "Salvateur" to "حامٍ",
                "Chasseur" to "صياد",
            )[it.groupValues[2]] ?: it.groupValues[2]
            return "${it.groupValues[1]} هو $role."
        }
        Regex("""^Your Wolf friends: (.+)$""").matchEntire(text)?.let { return "رفاقك من الذئاب: ${it.groupValues[1]}" }
        Regex("""^Your pack: (.+)\.$""").matchEntire(text)?.let { return "فريقك: ${it.groupValues[1]}." }
        Regex("""^The Wolves targeted (.+)\.$""").matchEntire(text)?.let { return "اختارت الذئاب ${it.groupValues[1]} هدفاً." }
        Regex("""^The Wolves attacked (.+), but the Witch healed them\.$""").matchEntire(text)?.let {
            return "هاجمت الذئاب ${it.groupValues[1]}، لكن الساحرة عالجته."
        }
        Regex("""^The Wolves attacked (.+), but the Salvateur protected them\.$""").matchEntire(text)?.let {
            return "هاجمت الذئاب ${it.groupValues[1]}، لكن الحامي أنقذه."
        }
        Regex("""^The Wolves attacked (.+), but the Witch and the Salvateur saved them\.$""").matchEntire(text)?.let {
            return "هاجمت الذئاب ${it.groupValues[1]}، لكن الساحرة والحامي أنقذاه."
        }
        Regex("""^(.+) was killed by the Wolves\.$""").matchEntire(text)?.let { return "قُتل ${it.groupValues[1]} على يد الذئاب." }
        Regex("""^(.+) was killed by the Wolves and the Witch\.$""").matchEntire(text)?.let {
            return "قُتل ${it.groupValues[1]} على يد الذئاب والساحرة."
        }
        Regex("""^(.+) was killed by the Witch's poison\.$""").matchEntire(text)?.let {
            return "قُتل ${it.groupValues[1]} بسم الساحرة."
        }
        Regex("""^(.+) was voted out by the village\.$""").matchEntire(text)?.let { return "أخرجت القرية ${it.groupValues[1]} بالتصويت." }
        Regex("""^(.+) was killed by a final shot\.$""").matchEntire(text)?.let { return "قُتل ${it.groupValues[1]} بالطلقة الأخيرة." }
        Regex("""^(.+) chose (.+) as the new Village Chief\.$""").matchEntire(text)?.let {
            return "اختار ${it.groupValues[1]} ${it.groupValues[2]} ليكون عمدة القرية الجديد."
        }
        Regex("""^(.+) is choosing who votes first, second, and next\.$""").matchEntire(text)?.let {
            return "${it.groupValues[1]} يختار ترتيب المصوّتين."
        }
        Regex("""^(.+) is choosing the voting order\.$""").matchEntire(text)?.let {
            return "${it.groupValues[1]} يختار ترتيب التصويت."
        }
        Regex("""^Wait for (.+) to cast their vote\.$""").matchEntire(text)?.let {
            return "انتظر حتى يصوّت ${it.groupValues[1]}."
        }
        Regex("""^Voting order\n(.+)$""").matchEntire(text)?.let {
            return "ترتيب التصويت\n${it.groupValues[1]}"
        }
        if (text.contains('\n')) return text.lines().joinToString("\n") { localize(it, true) }
        return text
    }
}
